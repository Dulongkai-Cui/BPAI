import { AcDbFontInfo, AcDbFontLoader } from '@mlightcad/data-model';
/**
 * Font loader implementation for CAD text rendering.
 *
 * This class implements the {@link AcDbFontLoader} interface and provides functionality to:
 * - Fetch available font metadata from a CDN
 * - Load required fonts for CAD text rendering
 * - Handle font loading errors and emit appropriate events
 * - Manage font availability checking
 *
 * The font loader works with a Three.js renderer to load fonts that are used
 * for rendering CAD text entities like MText and Text.
 *
 * @example
 * ```typescript
 * const renderer = new AcTrRenderer();
 * const fontLoader = new AcApFontLoader(renderer);
 *
 * // Load specific fonts
 * await fontLoader.load(['Arial', 'SimSun']);
 *
 * // Get all available fonts
 * const fonts = await fontLoader.getAvaiableFonts();
 * console.log('Available fonts:', fonts);
 * ```
 */
export declare class AcApFontLoader implements AcDbFontLoader {
    /** Font loader in mtext-render */
    private _loader;
    /**
     * Creates a new font loader instance.
     *
     * @param renderer - The Three.js renderer that will use the loaded fonts
     */
    constructor();
    /**
     * Base URL to load fonts
     */
    get baseUrl(): string;
    set baseUrl(value: string);
    /**
     * Avaiable fonts to load.
     */
    get avaiableFonts(): AcDbFontInfo[];
    /**
     * @inheritdoc
     */
    getAvaiableFonts(): Promise<AcDbFontInfo[]>;
    /**
     * @inheritdoc
     */
    load(fontNames: string[]): Promise<void>;
}
//# sourceMappingURL=AcApFontLoader.d.ts.map