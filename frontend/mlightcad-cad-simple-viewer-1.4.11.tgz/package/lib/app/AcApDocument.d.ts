import { AcDbDatabase } from '@mlightcad/data-model';
import { AcEdOpenMode } from '../editor/view';
import { AcApOpenDatabaseOptions } from './AcDbOpenDatabaseOptions';
/**
 * Represents a CAD document that manages a drawing database and associated metadata.
 *
 * This class handles:
 * - Opening CAD files from URIs or file content (DWG/DXF formats)
 * - Managing document properties (title, access mode)
 * - Providing access to the underlying database
 * - Handling file loading errors through event emission
 */
export declare class AcApDocument {
    /** The URI of the opened document, if opened from a URI */
    private _uri?;
    /** The underlying CAD database containing all drawing data */
    private _database;
    /** The file name of the document */
    private _fileName;
    /** The display title of the document */
    private _docTitle;
    /** The access mode for the document */
    private _openMode;
    /**
     * Creates a new document instance with an empty database.
     *
     * The document is initialized with an "Untitled" title and write mode enabled.
     */
    constructor();
    /**
     * Opens a CAD document from a URI.
     *
     * @param uri - The URI of the CAD file to open
     * @param options - Options for opening the database
     * @returns Promise resolving to true if successful, false if failed
     *
     * @example
     * ```typescript
     * const success = await document.openUri('https://example.com/drawing.dwg', {
     *   mode: AcEdOpenMode.Read
     * });
     * ```
     */
    openUri(uri: string, options: AcApOpenDatabaseOptions): Promise<boolean>;
    /**
     * Opens a CAD document from file content.
     *
     * @param fileName - The name of the file (used to determine file type from extension)
     * @param content - The file content as string or ArrayBuffer
     * @param options - Options for opening the database
     * @returns Promise resolving to true if successful, false if failed
     *
     * @example
     * ```typescript
     * const fileContent = await fetch('drawing.dwg').then(r => r.arrayBuffer());
     * const success = await document.openDocument('drawing.dwg', fileContent, {
     *   mode: AcEdOpenMode.Write
     * });
     * ```
     */
    openDocument(fileName: string, content: ArrayBuffer, options: AcApOpenDatabaseOptions): Promise<boolean>;
    /**
     * Gets the URI of the document if opened from a URI.
     *
     * @returns The document URI, or undefined if not opened from URI
     */
    get uri(): string | undefined;
    /**
     * Gets the database object containing all drawing data.
     *
     * @returns The underlying CAD database instance
     */
    get database(): AcDbDatabase;
    /**
     * Gets the display title of the document.
     *
     * @returns The title of the document
     */
    get docTitle(): string;
    /**
     * Sets the display title of the document.
     *
     * Notes:
     * The browser tab title isn't updated on purpose because users may use it as
     * one component and don't want to the browser tab title changed. So if you
     * want to change the browser tab title, you can listen events
     * `AcApDocManager.events.documentActivated` to change it in your event listener.
     *
     * @param value - The new document title
     */
    set docTitle(value: string);
    /**
     * Gets the access mode of the document.
     *
     * @returns The access mode (Read, Review, or Write)
     */
    get openMode(): AcEdOpenMode;
    /**
     * Extracts the file name from a URI.
     *
     * @param uri - The URI to extract the file name from
     * @returns The extracted file name, or empty string if extraction fails
     * @private
     */
    private getFileNameFromUri;
}
//# sourceMappingURL=AcApDocument.d.ts.map