/**
 * Configuration options for {@link AcApProgress}.
 */
export interface AcApProgressOptions {
    /**
     * Host element where overlay is mounted.
     * Use the CAD view container so mask is scoped to canvas area.
     * @defaultValue `document.body`
     */
    host?: HTMLElement;
    /**
     * Size of the circular loader (width & height).
     * Accepts any valid CSS length value (e.g. "48px", "3rem", "25%").
     * @defaultValue `"48px"`
     */
    size?: string;
    /**
     * Width of the spinner border stroke.
     * Should be a valid CSS length value.
     * @defaultValue `"5px"`
     */
    borderWidth?: string;
    /**
     * Color of the animated spinner arc.
     * Accepts any valid CSS color format.
     * @defaultValue `"#0b84ff"`
     */
    color?: string;
    /**
     * Whether a fullscreen overlay background is shown.
     * @defaultValue `true`
     */
    overlay?: boolean;
    /**
     * Background color used when {@link overlay} is enabled.
     * @defaultValue `"rgba(0,0,0,0.18)"`
     */
    overlayColor?: string;
    /**
     * Optional message text displayed under the spinner.
     * Hidden automatically if empty or undefined.
     * @defaultValue `""`
     */
    message?: string;
}
/**
 * Displays a centered infinite circular loading indicator with optional text.
 *
 * Features:
 * - Framework-free — pure TypeScript & DOM
 * - Auto-injects required CSS once per document
 * - Shows/hides without removing DOM
 * - Dynamically update message text
 * - Safe for multiple instances
 *
 * @example
 * ```ts
 * const progress = new AcApProgress({ message: "Loading data…" });
 * progress.show();
 *
 * setTimeout(() => {
 *   progress.setMessage("Almost done…");
 * }, 1500);
 *
 * // progress.hide();
 * // progress.destroy();
 * ```
 */
export declare class AcApProgress {
    /**
     * ID assigned to the injected `<style>` element.
     * Used to ensure styles are only injected once.
     */
    static readonly styleId: string;
    /**
     * Tracks whether component CSS has already been injected.
     */
    static stylesInjected: boolean;
    /**
     * Root overlay container element appended to the configured host.
     */
    root: HTMLDivElement;
    /**
     * Spinner circle element.
     */
    spinner: HTMLDivElement;
    /**
     * Message text element displayed under the spinner.
     */
    messageEl: HTMLDivElement;
    /**
     * Immutable resolved configuration for this instance.
     */
    readonly options: Required<AcApProgressOptions>;
    /**
     * Creates a new fullscreen infinite progress indicator.
     *
     * @param options - Optional {@link AcApProgressOptions} controlling appearance & behavior
     */
    constructor(options?: AcApProgressOptions);
    /**
     * Makes the progress indicator visible.
     * The DOM remains mounted for efficiency.
     *
     * @returns The current {@link AcApProgress} instance (for chaining)
     */
    show(): this;
    /**
     * Hides the progress indicator without removing it from the DOM.
     *
     * @returns The current {@link AcApProgress} instance (for chaining)
     */
    hide(): this;
    /**
     * Updates the displayed message text beneath the spinner.
     *
     * If the message is empty or undefined, the message element is hidden.
     *
     * @param text - New message text
     * @returns The current {@link AcApProgress} instance (for chaining)
     */
    setMessage(text?: string): this;
    /**
     * Completely removes the component from the DOM.
     * Safe to call multiple times.
     */
    destroy(): void;
    /**
     * Creates required DOM elements and mounts them into configured host.
     * Called automatically by constructor.
     */
    private createDom;
    /**
     * Injects required CSS into the document `<head>` if not already present.
     * Called automatically and only once globally.
     */
    private injectStyles;
}
//# sourceMappingURL=AcApProgress.d.ts.map