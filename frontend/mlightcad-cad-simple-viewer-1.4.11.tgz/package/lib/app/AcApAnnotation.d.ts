import { AcCmColor, AcDbDatabase, AcDbObject, AcDbObjectId, AcGiLineWeight } from '@mlightcad/data-model';
export declare class AcApAnnotation {
    /**
     * Default annotation color is red
     */
    static DEFAULT_ANNOTATION_COLOR: AcCmColor;
    static DEFAULT_ANNOTATION_LINE_WEIGHT: AcGiLineWeight;
    private _database;
    constructor(db: AcDbDatabase);
    /**
     * Finds or creates a annotation layer identified by MLightCAD-specific XData.
     *
     * This method enforces the concept of a *singleton annotation layer* in a drawing.
     * It first scans all existing layers and looks for one whose XData contains
     * a description value of `"mlightcad"` under the registered application name
     * `"mlightcad"`.
     *
     * Behavior:
     * - If such a layer already exists, its name is returned and **no new layer
     *   is created**.
     * - If no matching layer is found, a new layer is created with:
     *   - A unique name using the prefix `"$revision_"` followed by a numeric index
     *     (e.g. `$revision_1`, `$revision_2`, …)
     *   - Yellow color (ACI = 2)
     *   - Layer turned on and plottable
     *   - XData attached to mark it as an MLightCAD annotation layer
     *
     * XData layout:
     * - RegApp name: `"mlightcad"`
     * - Description (ASCII string): `"mlightcad"`
     *
     * The attached XData allows the annotation layer to be reliably identified even
     * if the layer is renamed by the user.
     *
     * @returns The name of the existing or newly created annotation layer.
     */
    getAnnotationLayer(): string;
    filterAnnotationEntities(ids: AcDbObjectId[]): string[];
    /**
     * Returns true if the specified object contains annotation xdata, which means
     * it is only object created by annotation related commands.
     * @param object - Object to check whether it contains annotation xdata.
     * @returns Returns true if the specified object contains annotation xdata.
     */
    hasAnnotationXData(object: AcDbObject): boolean;
}
//# sourceMappingURL=AcApAnnotation.d.ts.map