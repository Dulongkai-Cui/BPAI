import { AcCmEventManager } from '@mlightcad/data-model';
/**
 * Font mappings for CAD text rendering.
 *
 * Maps original font names to replacement font names when the original
 * font is not available in the system.
 *
 * @example
 * ```typescript
 * const fontMapping: AcApFontMapping = {
 *   'AutoCAD Font': 'Arial',
 *   'SimSun': 'Microsoft YaHei'
 * };
 * ```
 */
export type AcApFontMapping = Record<string, string>;
/**
 * Configuration settings for the CAD application.
 *
 * Contains various UI and rendering preferences that can be persisted
 * and modified during runtime.
 */
export interface AcApSettings {
    /** Whether debug mode is enabled for development features */
    isDebug: boolean;
    /** Whether the command line interface is visible */
    isShowCommandLine: boolean;
    /** Whether coordinate display is visible */
    isShowCoordinate: boolean;
    /** Whether entity info card is visible */
    isShowEntityInfo: boolean;
    /** Whether file name is visible */
    isShowFileName: boolean;
    /** Whether language selector is visible */
    isShowLanguageSelector: boolean;
    /** Whether main menu is visible */
    isShowMainMenu: boolean;
    /** Whether the toolbar is visible */
    isShowToolbar: boolean;
    /** Whether performance statistics are displayed */
    isShowStats: boolean;
    /** Font mapping configuration for text rendering */
    fontMapping: AcApFontMapping;
    /** Object snap modes */
    osnapModes: number;
}
/**
 * Event arguments for settings modification events.
 *
 * @template T - The settings type, defaults to AcApSettings
 */
export interface AcApSettingManagerEventArgs<T extends AcApSettings = AcApSettings> {
    /** The setting key that was modified */
    key: keyof T;
    /** The new value of the setting */
    value: unknown;
}
/**
 * Singleton settings manager for the CAD application.
 *
 * This class manages application-wide settings with:
 * - Persistent storage using localStorage
 * - Event notification when settings change
 * - Type-safe setting access
 * - Default value fallbacks
 *
 * The settings are automatically saved to localStorage and restored on application start.
 *
 * @template T - The settings interface type, defaults to AcApSettings
 *
 * @example
 * ```typescript
 * // Get the singleton instance
 * const settings = AcApSettingManager.instance;
 *
 * // Set a setting value
 * settings.set('isShowToolbar', false);
 *
 * // Get a setting value
 * const showToolbar = settings.get('isShowToolbar');
 *
 * // Toggle a boolean setting
 * settings.toggle('isDebug');
 *
 * // Listen for setting changes
 * settings.events.modified.addEventListener(args => {
 *   console.log(`Setting ${args.key} changed to:`, args.value);
 * });
 * ```
 */
export declare class AcApSettingManager<T extends AcApSettings = AcApSettings> {
    /** Singleton instance */
    private static _instance?;
    /** Events fired when settings are modified */
    readonly events: {
        /** Fired when any setting is modified */
        modified: AcCmEventManager<AcApSettingManagerEventArgs<T>>;
    };
    /**
     * Gets the singleton instance of the settings manager.
     *
     * Creates a new instance if one doesn't exist yet.
     *
     * @returns The singleton settings manager instance
     */
    static get instance(): AcApSettingManager<AcApSettings>;
    /**
     * Sets a setting value and persists it to localStorage.
     *
     * Fires a modified event after the setting is saved.
     *
     * @template K - The setting key type
     * @param key - The setting key to modify
     * @param value - The new value for the setting
     *
     * @example
     * ```typescript
     * settings.set('isShowToolbar', false);
     * settings.set('fontMapping', { 'Arial': 'Helvetica' });
     * ```
     */
    set<K extends keyof T>(key: K, value: T[K]): void;
    /**
     * Gets a setting value.
     *
     * Returns the stored value or the default value if not set.
     *
     * @template K - The setting key type
     * @param key - The setting key to retrieve
     * @returns The setting value
     *
     * @example
     * ```typescript
     * const isDebug = settings.get('isDebug');
     * const fontMapping = settings.get('fontMapping');
     * ```
     */
    get<K extends keyof T>(key: K): NonNullable<AcApSettings & T>[K];
    /**
     * Toggles a boolean setting value.
     *
     * Only works with boolean settings. The caller should ensure the setting is boolean.
     *
     * @template K - The setting key type
     * @param key - The boolean setting key to toggle
     *
     * @example
     * ```typescript
     * settings.toggle('isDebug');        // false -> true
     * settings.toggle('isShowToolbar');  // true -> false
     * ```
     */
    toggle<K extends keyof T>(key: K): void;
    /**
     * Gets whether debug mode is enabled.
     *
     * @returns True if debug mode is enabled
     */
    get isDebug(): boolean;
    /**
     * Sets whether debug mode is enabled.
     *
     * @param value - True to enable debug mode
     */
    set isDebug(value: boolean);
    /**
     * Gets whether the command line is visible.
     *
     * @returns True if command line should be shown
     */
    get isShowCommandLine(): boolean;
    /**
     * Sets whether the command line is visible.
     *
     * @param value - True to show the command line
     */
    set isShowCommandLine(value: boolean);
    /**
     * Gets whether coordinate display is visible.
     *
     * @returns True if coordinates should be displayed
     */
    get isShowCoordinate(): boolean;
    /**
     * Sets whether coordinate display is visible.
     *
     * @param value - True to show coordinates
     */
    set isShowCoordinate(value: boolean);
    /**
     * Gets whether entity info card is visible.
     *
     * @returns True if entity info card should be displayed
     */
    get isShowEntityInfo(): boolean;
    /**
     * Sets whether entity info card is visible.
     *
     * @param value - True to show entity info card
     */
    set isShowEntityInfo(value: boolean);
    /**
     * Gets whether file name is visible.
     *
     * @returns True if file name should be displayed
     */
    get isShowFileName(): boolean;
    /**
     * Sets whether file name is visible.
     *
     * @param value - True to show file name
     */
    set isShowFileName(value: boolean);
    /**
     * Gets whether language selector is visible.
     *
     * @returns True if language selector should be displayed
     */
    get isShowLanguageSelector(): boolean;
    /**
     * Sets whether language selector is visible.
     *
     * @param value - True to show language selector
     */
    set isShowLanguageSelector(value: boolean);
    /**
     * Gets whether the main menu is visible.
     *
     * @returns True if the main menu should be displayed
     */
    get isShowMainMenu(): boolean;
    /**
     * Sets whether the main menu is visible.
     *
     * @param value - True to show the main menu
     */
    set isShowMainMenu(value: boolean);
    /**
     * Gets whether the toolbar is visible.
     *
     * @returns True if toolbar should be shown
     */
    get isShowToolbar(): boolean;
    /**
     * Sets whether the toolbar is visible.
     *
     * @param value - True to show the toolbar
     */
    set isShowToolbar(value: boolean);
    /**
     * Gets whether performance statistics are displayed.
     *
     * @returns True if stats should be shown
     */
    get isShowStats(): boolean;
    /**
     * Sets whether performance statistics are displayed.
     *
     * @param value - True to show stats
     */
    set isShowStats(value: boolean);
    /**
     * Gets the font mapping configuration.
     *
     * @returns The current font mapping
     */
    get fontMapping(): AcApFontMapping;
    /**
     * Sets the font mapping configuration.
     *
     * @param value - The new font mapping
     */
    set fontMapping(value: AcApFontMapping);
    /**
     * Sets a single font mapping entry.
     *
     * @param originalFont - The original font name
     * @param mappedFont - The replacement font name
     */
    setFontMapping(originalFont: string, mappedFont: string): void;
    /**
     * Gets the object snapping configuration.
     *
     * @returns The current object snapping configuration.
     */
    get osnapModes(): number;
    /**
     * Sets the object snapping configuration.
     *
     * @param value - The new object snapping configuration.
     */
    set osnapModes(value: number);
    /**
     * Gets the current settings object.
     *
     * This method combines localStorage values with default values.
     *
     * @returns The current settings object
     */
    get settings(): NonNullable<AcApSettings & T>;
}
//# sourceMappingURL=AcApSettingManager.d.ts.map