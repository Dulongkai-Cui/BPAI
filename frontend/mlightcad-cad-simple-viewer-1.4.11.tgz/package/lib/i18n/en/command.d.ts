declare const _default: {
    ACAD: {
        cecolor: {
            description: string;
        };
        celtscale: {
            description: string;
        };
        celweight: {
            description: string;
        };
        clayer: {
            description: string;
        };
        circle: {
            description: string;
        };
        colortheme: {
            description: string;
        };
        csvg: {
            description: string;
        };
        dimlinear: {
            description: string;
        };
        erase: {
            description: string;
            prompt: string;
        };
        line: {
            description: string;
        };
        mtext: {
            description: string;
        };
        log: {
            description: string;
        };
        open: {
            description: string;
        };
        pan: {
            description: string;
        };
        pickbox: {
            description: string;
        };
        qnew: {
            description: string;
        };
        rectangle: {
            description: string;
        };
        regen: {
            description: string;
        };
        revcloud: {
            description: string;
        };
        select: {
            description: string;
        };
        sketch: {
            description: string;
        };
        whitebkcolor: {
            description: string;
        };
        zoom: {
            description: string;
        };
        zoomw: {
            description: string;
        };
    };
    USER: {};
};
export default _default;
//# sourceMappingURL=command.d.ts.map