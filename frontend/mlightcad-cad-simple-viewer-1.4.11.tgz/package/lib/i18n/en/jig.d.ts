declare const _default: {
    circle: {
        center: string;
        radius: string;
    };
    measureDistance: {
        firstPoint: string;
        secondPoint: string;
    };
    measureArea: {
        firstPoint: string;
        nextPoint: string;
    };
    measureAngle: {
        vertex: string;
        arm1: string;
        arm2: string;
    };
    measureArc: {
        startPoint: string;
        throughPoint: string;
        endPoint: string;
    };
    dimlinear: {
        xLine1Point: string;
        xLine2Point: string;
        dimLinePoint: string;
    };
    line: {
        firstPoint: string;
        nextPoint: string;
    };
    mtext: {
        point: string;
    };
    rect: {
        firstPoint: string;
        nextPoint: string;
    };
    sketch: {
        firstPoint: string;
        nextPoint: string;
    };
    sysvar: {
        prompt: string;
    };
};
export default _default;
//# sourceMappingURL=jig.d.ts.map