declare const _default: {
    commandLine: {
        noLast: string;
        unknownCommand: string;
        executed: string;
        showHistory: string;
        placeholder: string;
        showMessages: string;
        canceled: string;
        noHistory: string;
        close: string;
    };
    inputManager: {
        firstCorner: string;
        secondCorner: string;
    };
    message: {
        fetchingDrawingFile: string;
    };
    progress: {
        start: string;
        parse: string;
        font: string;
        ltype: string;
        style: string;
        dimstyle: string;
        layer: string;
        vport: string;
        blockrecord: string;
        header: string;
        block: string;
        entity: string;
        object: string;
        end: string;
    };
};
export default _default;
//# sourceMappingURL=main.d.ts.map