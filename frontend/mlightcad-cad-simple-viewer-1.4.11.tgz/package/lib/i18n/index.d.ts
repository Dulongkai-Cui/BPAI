import { AcApI18n, AcApLocale } from './AcApI18n';
export declare const cmdDescription: (groupName: string, cmdName: string) => string;
export declare const sysCmdDescription: (name: string) => string;
export declare const userCmdDescription: (name: string) => string;
export { AcApI18n, type AcApLocale };
//# sourceMappingURL=index.d.ts.map