import { AcCmEventManager } from '@mlightcad/data-model';
/**
 * Language/locale id used in the application.
 * Matches the naming style used by vue-i18n ("Locale").
 */
export type AcApLocale = 'en' | 'zh';
/**
 * A single locale message tree.
 * Leaf values are strings, inner nodes are nested objects of the same shape.
 * This mirrors vue-i18n's LocaleMessage structure.
 */
export interface AcApLocaleMessage {
    [key: string]: string | AcApLocaleMessage;
}
/**
 * The whole messages map: locale -> locale message tree.
 * This mirrors vue-i18n's "LocaleMessages".
 */
export type AcApLocaleMessages = Record<AcApLocale, AcApLocaleMessage>;
/**
 * Options for translation lookup.
 */
export interface AcApTranslateOptions {
    fallback?: string;
}
/**
 * Event arguments for locale changed events.
 */
export interface AcApLocaleChangedEventArgs {
    /** The old locale value */
    old: AcApLocale;
    /** The new locale value */
    new: AcApLocale;
}
/**
 * A framework-agnostic i18n registry with vue-i18n-like API names.
 *
 * Key methods:
 * - getLocaleMessages(): returns all messages (for vue-i18n { messages })
 * - getLocaleMessage(locale): returns single locale messages
 * - setLocaleMessage(locale, messages): replace locale messages
 * - mergeLocaleMessage(locale, messages): deep-merge into existing locale (fixed)
 * - t(locale, key, options): translation helper for core code (no Vue required)
 */
export declare class AcApI18n {
    private static _messages;
    /**
     * @private
     *
     * Stores the currently active locale used by the translation
     * system. Defaults to `"en"`.
     *
     * This value is used by `t(key, options)` when no locale
     * parameter is provided.
     */
    private static _currentLocale;
    /**
     * Return the whole messages map (for vue-i18n initialisation).
     */
    static get messages(): Readonly<AcApLocaleMessages>;
    /** Supported events */
    static readonly events: {
        /** Fired when locale changed */
        localeChanged: AcCmEventManager<AcApLocaleChangedEventArgs>;
    };
    /**
     * Return the messages object for a single locale.
     */
    static getLocaleMessage(locale: AcApLocale): Readonly<AcApLocaleMessage>;
    /**
     * Deep-merge a message dictionary into an existing locale.
     */
    static mergeLocaleMessage<L extends AcApLocale>(locale: L, messages: AcApLocaleMessage): void;
    /**
     * Register a plugin's messages.
     * Alias for mergeLocaleMessage for consistency with vue-i18n.
     */
    static registerMessage<L extends AcApLocale>(locale: L, messages: AcApLocaleMessage): void;
    /**
     * Set the current active locale for translation.
     *
     * @param locale - Locale to activate (`"en"` or `"zh"`)
     *
     * @remarks
     * This method updates the internal locale state used by all
     * future calls to `t(key, options)`. After calling this method,
     * the entire application will use the new locale automatically.
     *
     * @example
     * ```ts
     * AcApI18n.setCurrentLocale('zh')
     * console.log(AcApI18n.t('core.start'))   // uses Chinese messages
     * ```
     */
    static setCurrentLocale(locale: AcApLocale): void;
    /**
     * Get the currently active locale.
     *
     * @returns The locale currently used for translation.
     *
     * @example
     * ```ts
     * console.log(AcApI18n.currentLocale)  // "en" or "zh"
     * ```
     */
    static get currentLocale(): AcApLocale;
    /**
     * Translate a dotted key path using the registry (no Vue required).
     *
     * @param key - dotted path, e.g. "core.start" or "pluginX.button.ok"
     * @param options - optional fallback
     * @returns translated string or fallback/key if not found
     */
    static t(key: string, options?: AcApTranslateOptions): string;
    /**
     * Get localized command description
     * @param groupName - Command group name
     * @param cmdName - Global command name
     * @returns - The localized command description.
     */
    static cmdDescription(groupName: string, cmdName: string): string;
    /**
     * Get localized command prommpt message
     * @param groupName - Command group name
     * @param cmdName - Global command name
     * @returns - The localized command prompt message.
     */
    static cmdPrompt(groupName: string, cmdName: string): string;
    /**
     * Tries to find command in system group and gets its localized command description
     * @param cmdName - Global command name
     * @returns - The localized command description
     */
    static sysCmdDescription(name: string): string;
    /**
     * Tries to find command in user group and gets its localized command description
     * @param cmdName - Global command name
     * @returns - The localized command description
     */
    static userCmdDescription: (name: string) => string;
    /**
     * Tries to find command in system group and gets its localized command prompt message
     * @param cmdName - Global command name
     * @returns - The localized command prompt message
     */
    static sysCmdPrompt(name: string): string;
    /**
     * Tries to find command in user group and gets its localized command prompt message
     * @param cmdName - Global command name
     * @returns - The localized command prompt message
     */
    static userCmdPrompt: (name: string) => string;
}
//# sourceMappingURL=AcApI18n.d.ts.map