import { AcCmColor, AcDbDatabase } from '@mlightcad/data-model';
/** Returns the current measurement overlay color from the MEASUREMENTCOLOR system variable. */
export declare function measurementColor(db: AcDbDatabase): AcCmColor;
/** Converts an AcCmColor to a CSS rgb() string. */
export declare function colorToCss(c: AcCmColor): string;
/** Converts an AcCmColor to a CSS rgba() string. */
export declare function colorToCssAlpha(c: AcCmColor, alpha: number): string;
/** Creates a small dot element for marking world points. */
export declare function makeDot(c: AcCmColor): HTMLDivElement;
/** Creates a badge element for displaying measurement values. */
export declare function makeBadge(c: AcCmColor, text?: string): HTMLDivElement;
//# sourceMappingURL=AcApMeasurementUtils.d.ts.map