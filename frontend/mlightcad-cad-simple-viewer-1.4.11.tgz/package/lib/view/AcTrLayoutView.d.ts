import { AcTrBaseView, AcTrRenderer, AcTrViewportView } from '@mlightcad/three-renderer';
import * as THREE from 'three';
import { AcEdViewMode } from '../editor/view/AcEdBaseView';
import { AcTrScene } from './AcTrScene';
/**
 * Interface for database entity event arguments.
 * Provides context information for entity-related events.
 */
export interface AcDbEntityEventArgs {
    /** The layout view associated with the event */
    view: AcTrLayoutView;
}
/**
 * Each layout has its own camera and camera control. This class represents view associated with one layout.
 *
 * A layout view manages the visual representation and interaction for a specific AutoCAD layout.
 * It provides:
 * - Camera and view controls specific to the layout
 * - Viewport management for paper space layouts
 * - View mode switching (selection, pan, etc.)
 * - Axes gizmo for orientation feedback
 * - Rendering coordination with viewports
 *
 * The layout view coordinates between the layout's data (entities, layers) and the visual
 * presentation, handling camera positioning, user interaction modes, and multi-viewport
 * rendering for paper space layouts.
 *
 * @example
 * ```typescript
 * const layoutView = new AcTrLayoutView(renderer, layoutId, 800, 600);
 * layoutView.mode = AcEdViewMode.PAN;
 * layoutView.render(scene);
 * ```
 */
export declare class AcTrLayoutView extends AcTrBaseView {
    /** The block table record ID associated with this layout */
    private _layoutBtrId;
    /** The axes gizmo for showing coordinate system orientation */
    private _axesGizmo;
    /** The current view mode (selection, pan, etc.) */
    private _mode;
    /** Map of viewport views indexed by viewport ID */
    private _viewportViews;
    /**
     * Construct one instance of this class.
     *
     * @param renderer - Input renderer for this view
     * @param layoutBtrId - Input the id of the block table record associated the layout
     * @param width - Input width of this view in pixels
     * @param height - Input height of this view in pixels
     */
    constructor(renderer: AcTrRenderer, layoutBtrId: string, width: number, height: number);
    /**
     * Gets the block table record ID associated with this layout.
     *
     * @returns The layout's block table record ID
     */
    get layoutBtrId(): string;
    /**
     * The view mode of the current layout view.
     * Controls how mouse interactions are interpreted (selection vs pan mode).
     */
    get mode(): AcEdViewMode;
    set mode(value: AcEdViewMode);
    /**
     * The number of viewports in this layout view.
     * Paper space layouts can contain multiple viewports showing different views of model space.
     */
    get viewportCount(): number;
    /**
     * The internal THREE camera used by this layout view.
     */
    get internalCamera(): THREE.OrthographicCamera;
    /**
     * Add one viewport view instance to this layout view.
     * Viewports are used in paper space layouts to show different views of the model.
     *
     * @param viewportView - Input one viewport instance to add
     */
    addViewport(viewportView: AcTrViewportView): void;
    /**
     * Remove the specified viewport view by its id from this layout view.
     *
     * @param id - Input the id of one viewport instance to remove
     */
    removeViewport(id: string): void;
    /**
     * Resize this layout view.
     * Updates the view dimensions and notifies all viewports of the size change.
     *
     * @param width - Input new width of the layout view in pixels
     * @param height - Input new height of the layout view in pixels
     */
    resize(width: number, height: number): void;
    /**
     * Renders the scene in this layout view.
     * Performs the main rendering pass and then renders any viewports if present.
     * Updates the axes gizmo to reflect the current camera orientation.
     *
     * @param scene - The scene containing the layout data to render
     */
    render(scene: AcTrScene): void;
    /**
     * Creates and configures the axes gizmo for this view.
     * The gizmo shows the current coordinate system orientation and is positioned
     * at the bottom-left of the view without a Z-axis (2D view).
     *
     * @returns The configured axes gizmo instance
     */
    private createAxesGizmo;
    /**
     * Draw viewports into the current rendering context.
     * Handles the complex rendering process for paper space layouts that contain
     * multiple viewports, each with their own view of model space.
     *
     * @param scene - Input the scene object to draw in each viewport
     */
    private drawViewports;
}
//# sourceMappingURL=AcTrLayoutView.d.ts.map