import { AcDbObjectId, AcGeBox2d, AcGeBox3d } from '@mlightcad/data-model';
import { AcTrEntity, AcTrHtmlTransientManager } from '@mlightcad/three-renderer';
import { AcEdLayerInfo } from 'editor';
import * as THREE from 'three';
import { AcTrLayer } from './AcTrLayer';
import { AcTrLayout, AcTrLayoutStats } from './AcTrLayout';
export interface AcTrSceneStats {
    layouts: AcTrLayoutStats[];
    summary: {
        layoutCount: number;
        entityCount: number;
        totalSize: {
            line: number;
            mesh: number;
            point: number;
            unbatched: number;
            geometry: number;
            mapping: number;
            unbatchedCount: number;
            unbatchedByType: {
                line: number;
                mesh: number;
                point: number;
                other: number;
            };
        };
    };
}
/**
 * Three.js scene manager for CAD drawings with hierarchical organization.
 *
 * The scene manages the complete visual representation of a CAD drawing using
 * a hierarchical structure that mirrors CAD data organization:
 *
 * ```
 * Scene
 * └── Layout (AcTrLayout) - Paper space or model space
 *     └── Layer (AcTrLayer) - Drawing layers for organization
 *         └── Entity (AcTrEntity) - Individual CAD entities (lines, arcs, etc.)
 * ```
 *
 * ## Key Responsibilities
 * - **Layout Management**: Handles multiple layouts (model space and paper spaces)
 * - **Layer Organization**: Manages layer visibility and entity grouping
 * - **Entity Rendering**: Provides access to all renderable CAD entities
 * - **Spatial Queries**: Calculates bounding boxes and spatial relationships
 * - **Three.js Integration**: Maintains the underlying Three.js scene
 *
 * The scene automatically manages the active layout and provides efficient
 * access to entities for rendering, selection, and spatial operations.
 *
 * @example
 * ```typescript
 * const scene = new AcTrScene();
 *
 * // Set up model space
 * scene.modelSpaceBtrId = modelSpaceId;
 *
 * // Add entities to layers
 * const entity = new AcTrLine(...);
 * scene.addEntity(entity, layerName);
 *
 * // Get all visible entities for rendering
 * const entities = scene.getAllEntities();
 *
 * // Get scene bounds for zoom operations
 * const bounds = scene.box;
 * ```
 */
export declare class AcTrScene {
    /** The underlying Three.js scene object */
    private _scene;
    /** Map of layout ID to layout object */
    private _layers;
    /** Map of layout ID to layout object */
    private _layouts;
    /** ID of the currently active layout */
    private _activeLayoutBtrId;
    /** ID of the model space layout */
    private _modelSpaceBtrId;
    /** Transient objects manager */
    private _transientManager;
    /** HTML transient elements manager */
    private _htmlTransientManager;
    /**
     * Creates a new CAD scene instance.
     *
     * Initializes the Three.js scene and layout management structures.
     */
    constructor();
    /**
     * The HTML transient elements manager for this scene
     */
    get htmlTransientManager(): AcTrHtmlTransientManager;
    /**
     * The layers in this scene
     */
    get layers(): Map<string, AcEdLayerInfo>;
    /**
     * The layouts in this scene
     */
    get layouts(): Map<string, AcTrLayout>;
    /**
     * The bounding box of the visibile objects in this secene
     */
    get box(): THREE.Box3 | undefined;
    /**
     * The scene object of THREE.js. This is internally used only. Try to avoid using it.
     */
    get internalScene(): THREE.Scene;
    /**
     * The block table record id of the model space
     */
    get modelSpaceBtrId(): AcDbObjectId;
    set modelSpaceBtrId(value: AcDbObjectId);
    /**
     * The block table record id associated with the current active layout
     */
    get activeLayoutBtrId(): string;
    set activeLayoutBtrId(value: string);
    /**
     * Get active layout
     */
    get activeLayout(): AcTrLayout | undefined;
    /**
     * Get the layout of the model space
     */
    get modelSpaceLayout(): AcTrLayout | undefined;
    /**
     * The statistics of this scene
     */
    get stats(): AcTrSceneStats;
    /**
     * Add one empty layout with the specified block table record id as the its key
     * @param ownerId Input the block table record id associated with this layout
     * @returns Return the newly created empty layout
     */
    addEmptyLayout(ownerId: AcDbObjectId): AcTrLayout;
    /**
     * Clear scene
     * @returns Return this scene
     */
    clear(): this;
    /**
     * Hover the specified entities
     */
    hover(ids: AcDbObjectId[]): boolean;
    /**
     * Unhover the specified entities
     */
    unhover(ids: AcDbObjectId[]): boolean;
    /**
     * Select the specified entities
     */
    select(ids: AcDbObjectId[]): boolean;
    /**
     * Unselect the specified entities
     */
    unselect(ids: AcDbObjectId[]): boolean;
    /**
     * Search entities intersected or contained in the specified bounding box.
     * @param box Input the query bounding box
     * @returns Return query results
     */
    search(box: AcGeBox2d | AcGeBox3d): import("editor").AcEdSpatialQueryResultItemEx[];
    addLayer(layer: AcEdLayerInfo): AcTrLayer[];
    updateLayer(layer: AcEdLayerInfo): AcTrLayer[];
    /**
     * Add the specified transient entity into this scene
     * @param entity Input one transient entity
     */
    addTransientEntity(entity: AcTrEntity): void;
    /**
     * Remove the specified transient entity from this scene
     * @param objectId Input the object id of the transient entity to remove
     */
    removeTransientEntity(objectId: AcDbObjectId): void;
    /**
     * Add one persistent entity (stored in the drawing database) into this scene. If the layout
     * associated with this entity doesn't exist, then create one layout, add this layout into
     * this scene, and add the entity into the layout.
     * @param entity Input AutoCAD entity to be added into scene.
     * @param extendBbox Input the flag whether to extend the bounding box of this scene by union the bounding box
     * of the specified entity.
     * @returns Return this scene
     */
    addEntity(entity: AcTrEntity, extendBbox?: boolean): this;
    /**
     * Remove the specified persistent entity (stored in the drawing database) from this scene.
     * @param objectId Input the object id of the entity to remove
     * @returns Return true if remove the specified entity successfully. Otherwise, return false.
     */
    removeEntity(objectId: AcDbObjectId): boolean;
    /**
     * Update the specified persistent entity (stored in the drawing database) in this scene.
     * @param objectId Input the entity to update
     * @returns Return true if update the specified entity successfully. Otherwise, return false.
     */
    updateEntity(entity: AcTrEntity): boolean;
}
//# sourceMappingURL=AcTrScene.d.ts.map