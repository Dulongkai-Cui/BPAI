export * from './AcTrView2d';
//# sourceMappingURL=index.d.ts.map