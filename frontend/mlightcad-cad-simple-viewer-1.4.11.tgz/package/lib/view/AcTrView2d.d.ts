import { AcDbEntity, AcDbLayerTableRecord, AcDbLayerTableRecordAttrs, AcDbLayout, AcDbObjectId, AcGeBox2d, AcGeBox3d, AcGePoint2d, AcGePoint2dLike } from '@mlightcad/data-model';
import { AcTrHtmlTransientManager, AcTrRenderer } from '@mlightcad/three-renderer';
import * as THREE from 'three';
import { AcEdBaseView, AcEdCalculateSizeCallback, AcEdSpatialQueryResultItemEx, AcEdViewMode } from '../editor';
import { AcTrLayoutView } from './AcTrLayoutView';
import { AcTrScene } from './AcTrScene';
/**
 * Options to customize view
 */
export interface AcTrView2dOptions {
    /**
     * Container HTML element used by renderer
     */
    container?: HTMLElement;
    /**
     * Callback function used to calculate size of canvas when window resized
     */
    calculateSizeCallback?: AcEdCalculateSizeCallback;
    /**
     * Background color
     */
    background?: number;
}
/**
 * Default view option values
 */
export declare const DEFAULT_VIEW_2D_OPTIONS: AcTrView2dOptions;
/**
 * A 2D CAD viewer component that renders CAD drawings using Three.js.
 *
 * This class extends {@link AcEdBaseView} and provides functionality for:
 * - Rendering 2D CAD drawings with Three.js WebGL renderer
 * - Handling user interactions (pan, zoom, select)
 * - Managing layouts, layers, and entities
 * - Supporting various CAD file formats (DWG, DXF)
 *
 * @example
 * ```typescript
 * const viewer = new AcTrView2d({
 *   canvas: document.getElementById('canvas') as HTMLCanvasElement,
 *   background: 0x000000,
 *   calculateSizeCallback: () => ({
 *     width: window.innerWidth,
 *     height: window.innerHeight
 *   })
 * });
 * ```
 */
export declare class AcTrView2d extends AcEdBaseView {
    /** The Three.js renderer wrapper for CAD rendering */
    private _renderer;
    /**
     * ID of the currently scheduled requestAnimationFrame callback.
     *
     * This value is used to:
     * - Track whether the animation loop is currently running
     * - Prevent scheduling multiple animation loops
     * - Cancel the animation loop when the view is paused, hidden, or disposed
     *
     * A value of `null` indicates that no animation frame is currently scheduled.
     */
    private _rafId;
    /** Manager for layout views and viewport handling */
    private _layoutViewManager;
    /** The 3D scene containing all CAD entities organized by layouts and layers */
    private _scene;
    /** Flag indicating if the view needs to be re-rendered */
    private _isDirty;
    /** Performance monitoring statistics display */
    private _stats;
    /** Map of missing raster images during rendering */
    private _missedImages;
    /** The number of entities waiting for processing */
    private _numOfEntitiesToProcess;
    /** CSS2D renderer for HTML transient overlays */
    private _css2dRenderer;
    /**
     * Creates a new 2D CAD viewer instance.
     *
     * @param options - Configuration options for the viewer
     * @param options.container - Optional HTML container element. If not provided, a new container will be created
     * @param options.calculateSizeCallback - Optional callback function to calculate canvas size on window resize
     * @param options.background - Optional background color as hex number (default: 0x000000)
     */
    constructor(options?: AcTrView2dOptions);
    /**
     * Initializes the viewer after renderer and camera are created.
     *
     * This method sets up the initial cursor and can be overridden by child classes
     * to add custom initialization logic.
     *
     * @protected
     */
    initialize(): void;
    /**
     * Gets the current view mode (selection or pan).
     *
     * @returns The current view mode
     * @inheritdoc
     */
    get mode(): AcEdViewMode;
    /**
     * Sets the view mode (selection or pan).
     *
     * @param value - The view mode to set
     */
    set mode(value: AcEdViewMode);
    /**
     * Gets the Three.js renderer wrapper used for CAD rendering.
     *
     * @returns The renderer instance
     */
    get renderer(): AcTrRenderer;
    /**
     * Gets whether the view needs to be re-rendered.
     *
     * @returns True if the view is dirty and needs re-rendering
     */
    get isDirty(): boolean;
    /**
     * Sets whether the view needs to be re-rendered.
     *
     * @param value - True to mark the view as needing re-rendering
     */
    set isDirty(value: boolean);
    /**
     * Gets information about missing data during rendering (fonts and images).
     *
     * @returns Object containing maps of missing fonts and images
     */
    get missedData(): {
        fonts: Record<string, number>;
        images: Map<string, string>;
    };
    get center(): AcGePoint2d;
    set center(value: AcGePoint2d);
    /**
     * Gets the background color of the view.
     *
     * The color is represented as a 24-bit hexadecimal RGB number, e.g.,
     * `0x000000` for black.
     */
    get backgroundColor(): number;
    /**
     * Sets the background color of the view.
     *
     * @param value - The background color as a 24-bit hexadecimal RGB number
     */
    set backgroundColor(value: number);
    /**
     * The block table record id of the model space
     */
    get modelSpaceBtrId(): AcDbObjectId;
    set modelSpaceBtrId(value: AcDbObjectId);
    /**
     * The block table record id associated with the active layout
     */
    get activeLayoutBtrId(): string;
    set activeLayoutBtrId(value: string);
    /**
     * The active layout view
     */
    get activeLayoutView(): AcTrLayoutView;
    /**
     * The statistics of the current scene
     */
    get stats(): import("./AcTrScene").AcTrSceneStats;
    /**
     * The internal THREE scene used by this view.
     */
    get internalScene(): THREE.Scene;
    /**
     * The HTML transient elements manager for placing overlays anchored to world coordinates.
     */
    get htmlTransientManager(): AcTrHtmlTransientManager;
    /**
     * The internal THREE camera used by current active layout.
     */
    get internalCamera(): THREE.OrthographicCamera;
    /**
     * Sets global ltscale
     */
    set ltscale(scale: number);
    /**
     * Sets global celtscale
     */
    set celtscale(scale: number);
    /**
     * @inheritdoc
     */
    screenToWorld(point: AcGePoint2dLike): AcGePoint2d;
    /**
     * @inheritdoc
     */
    worldToScreen(point: AcGePoint2dLike): AcGePoint2d;
    /**
     * @inheritdoc
     */
    zoomTo(box: AcGeBox2d, margin?: number): void;
    /**
     * Re-render points with latest point style settings
     * @param displayMode Input display mode of points
     */
    rerenderPoints(displayMode: number): void;
    /**
     * @inheritdoc
     */
    zoomToFitDrawing(timeout?: number): void;
    /**
     * @inheritdoc
     */
    zoomToFitLayer(layerName: string): boolean;
    /**
     * @inheritdoc
     */
    flyTo(point: AcGePoint2dLike, scale: number): void;
    /**
     * @inheritdoc
     */
    pick(point?: AcGePoint2dLike, hitRadius?: number, pickOneOnly?: boolean): AcEdSpatialQueryResultItemEx[];
    /**
     * @inheritdoc
     */
    search(box: AcGeBox2d | AcGeBox3d): AcEdSpatialQueryResultItemEx[];
    /**
     * @inheritdoc
     */
    select(point?: AcGePoint2dLike): void;
    /**
     * @inheritdoc
     */
    selectByBox(box: AcGeBox2d): void;
    /**
     * @inheritdoc
     */
    addLayer(layer: AcDbLayerTableRecord): void;
    /**
     * @inheritdoc
     */
    updateLayer(layer: AcDbLayerTableRecord, changes: Partial<AcDbLayerTableRecordAttrs>): void;
    /**
     * Add the specified transient entity or entities into this view
     * @param entity Input one or multiple transient entities
     */
    addTransientEntity(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * Remove the specified transient entity from this view
     * @param objectId Input the object id of the transient entity to remove
     */
    removeTransientEntity(objectId: AcDbObjectId): void;
    /**
     * @inheritdoc
     */
    addEntity(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * @inheritdoc
     */
    removeEntity(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * @inheritdoc
     */
    updateEntity(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * @inheritdoc
     */
    addLayout(layout: AcDbLayout): void;
    /**
     * @inheritdoc
     */
    clear(): void;
    /**
     * @inheritdoc
     */
    highlight(ids: AcDbObjectId[]): void;
    /**
     * @inheritdoc
     */
    unhighlight(ids: AcDbObjectId[]): void;
    stopAnimationLoop(): void;
    /**
     * @inheritdoc
     */
    onHover(id: AcDbObjectId): void;
    /**
     * @inheritdoc
     */
    onUnhover(id: AcDbObjectId): void;
    protected createScene(): AcTrScene;
    private createStats;
    protected onWindowResize(): void;
    private animate;
    private startAnimationLoop;
    /**
     * Create the layout view with the specified block table record id.
     * @param layoutBtrId Input the block table record id associated with the layout view.
     */
    private createLayoutViewIfNeeded;
    /**
     * Load entities from the specified layout if they haven't been loaded yet.
     * This ensures that when switching to a layout, all its entities are available for rendering.
     * @param layoutBtrId Input the block table record id of the layout
     */
    private loadLayoutEntitiesIfNeeded;
    /**
     * Show or hide stats component
     * @param show If it is true, show stats component. Otherwise, hide stats component.
     * Default value is false.
     */
    private toggleStatsVisibility;
    private drawEntity;
    static viewportIdCounter: number;
    /**
     * Converts the specified database entities to three entities
     * @param entities - The database entities
     * @returns The converted three entities
     */
    private batchConvert;
    private handleGroup;
    private decreaseNumOfEntitiesToProcess;
}
//# sourceMappingURL=AcTrView2d.d.ts.map