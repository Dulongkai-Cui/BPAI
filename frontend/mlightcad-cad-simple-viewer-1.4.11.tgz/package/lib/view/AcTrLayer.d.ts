import { AcDbObjectId } from '@mlightcad/data-model';
import { AcTrBatchedGroup, AcTrBatchedGroupStats, AcTrEntity } from '@mlightcad/three-renderer';
import * as THREE from 'three';
import { AcEdLayerInfo } from '../editor';
/**
 * Statistics for a CAD layer including name and batched rendering metrics.
 *
 * Extends the standard batched group statistics with layer-specific information.
 */
export type AcTrLayerStats = AcTrBatchedGroupStats & {
    /** The name of the layer */
    name: string;
    /** Statistics for non-batched objects in this layer */
    unbatched: {
        count: number;
        geometrySize: number;
        byType: {
            line: number;
            mesh: number;
            point: number;
            other: number;
        };
    };
};
/**
 * Represents a CAD layer for organizing and rendering entities in Three.js.
 *
 * This class manages a collection of CAD entities that belong to the same logical layer.
 * It provides:
 * - Entity organization and grouping
 * - Layer visibility control
 * - Efficient batched rendering through Three.js groups
 * - Performance monitoring and statistics
 *
 * ## Technical Notes
 * Unlike Three.js built-in layers (which only support 32 layers), this implementation
 * uses Three.js groups to represent AutoCAD layers, allowing unlimited layer support.
 * Each AutoCAD layer corresponds to one Three.js group containing all entities.
 *
 * ## Performance Benefits
 * - Batched rendering reduces draw calls
 * - Efficient visibility toggling for entire layers
 * - Optimized entity grouping for better GPU performance
 *
 * @example
 * ```typescript
 * // Create a new layer
 * const layer = new AcTrLayer('Dimensions');
 *
 * // Add entities to the layer
 * const line = new AcTrLine(startPoint, endPoint);
 * layer.add(line);
 *
 * // Control layer visibility
 * layer.visible = false; // Hide all entities in this layer
 *
 * // Get layer statistics
 * const stats = layer.stats;
 * console.log(`Layer ${stats.name} has ${stats.entityCount} entities`);
 * ```
 */
export declare class AcTrLayer {
    /**
     * Layer name
     */
    private _name;
    /**
     * This group contains all entities in this layer
     */
    private _group;
    /**
     * Bounding box containing all entities in this layer
     */
    private _box;
    /**
     * Construct one instance of this class
     * @param layer - Layer information
     */
    constructor(layer: AcEdLayerInfo);
    /**
     * Layer name
     */
    get name(): string;
    set name(value: string);
    /**
     * Gets the bounding box that contains all entities in this layer.
     *
     * @returns The layer's bounding box
     */
    get box(): THREE.Box3;
    get visible(): boolean;
    set visible(value: boolean);
    get internalObject(): AcTrBatchedGroup;
    /**
     * The statistics of this layer
     */
    get stats(): AcTrLayerStats;
    /**
     * The number of entities stored in this layer
     */
    get entityCount(): number;
    /**
     * Update layer information of this layer
     * @param value - New layer information
     */
    update(value: AcEdLayerInfo): void;
    /**
     * Find entities associated with the specified material and replace their material with new material
     * @param oldId - Id of the old material
     * @param material - The new material associated with entities
     */
    updateMaterial(oldId: number, material: THREE.Material): void;
    /**
     * Re-render points with latest point style settings
     * @param displayMode Input display mode of points
     */
    rerenderPoints(displayMode: number): void;
    /**
     * Return true if this layer contains the entity with the specified object id. Otherwise, return false.
     * @param objectId Input the object id of one entity
     * @returns Return true if this layer contains the entity with the specified object id. Otherwise,
     * return false.
     */
    hasEntity(objectId: AcDbObjectId): boolean;
    /**
     * Add one AutoCAD entity into this layer.
     * @param entity Input AutoCAD entity to be added into this layer.
     * @param extendBbox - Input the flag whether to extend the bounding box of the scene by union the bounding box
     * of the specified entity. Defaults to true.
     */
    addEntity(entity: AcTrEntity, extendBbox?: boolean): void;
    /**
     * Return true if the object with the specified object id is intersected with the ray by using raycast.
     * @param objectId  Input object id of object to check for intersection with the ray.
     * @param raycaster Input raycaster to check intersection
     */
    isIntersectWith(objectId: string, raycaster: THREE.Raycaster): boolean;
    /**
     * Remove the specified entity from this layer.
     * @param objectId Input the object id of the entity to remove
     * @returns Return true if remove the specified entity successfully. Otherwise, return false.
     */
    removeEntity(objectId: AcDbObjectId): boolean;
    /**
     * Update the specified entity in this layer.
     * @param entity Input the entity to update
     * @returns Return true if update the specified entity successfully. Otherwise, return false.
     */
    updateEntity(entity: AcTrEntity): boolean;
    /**
     * Clear all entities in this layer and release batched geometry resources.
     */
    clear(): void;
    /**
     * Hover the specified entities
     */
    hover(ids: AcDbObjectId[]): void;
    /**
     * Unhover the specified entities
     */
    unhover(ids: AcDbObjectId[]): void;
    /**
     * Select the specified entities
     */
    select(ids: AcDbObjectId[]): void;
    /**
     * Unselect the specified entities
     */
    unselect(ids: AcDbObjectId[]): void;
}
//# sourceMappingURL=AcTrLayer.d.ts.map