import { AcDbObjectId, AcGeBox2d, AcGeBox3d } from '@mlightcad/data-model';
import { AcTrEntity } from '@mlightcad/three-renderer';
import * as THREE from 'three';
import { AcEdLayerInfo } from '../editor';
import { AcTrLayer, AcTrLayerStats } from './AcTrLayer';
/**
 * Interface representing statistics for a layout.
 * Provides detailed information about the layout's content including
 * layer statistics and memory usage breakdown.
 */
export interface AcTrLayoutStats {
    /** Statistics for each layer in the layout */
    layers: AcTrLayerStats[];
    /** Summary statistics for the entire layout */
    summary: {
        /** Total number of entities across all layers */
        entityCount: number;
        /** Memory usage breakdown by object type */
        totalSize: {
            /** Memory used by line geometries (bytes) */
            line: number;
            /** Memory used by mesh geometries (bytes) */
            mesh: number;
            /** Memory used by point geometries (bytes) */
            point: number;
            /** Memory used by unbatched geometries (bytes) */
            unbatched: number;
            /** Total geometry memory usage (bytes) */
            geometry: number;
            /** Memory used by entity mappings (bytes) */
            mapping: number;
            /** Number of unbatched objects */
            unbatchedCount: number;
            /** Unbatched object count by type */
            unbatchedByType: {
                line: number;
                mesh: number;
                point: number;
                other: number;
            };
        };
    };
}
/**
 * This class represents objects contained in one AutoCAD layout (model space or paper space).
 *
 * A layout manages the organization and rendering of CAD entities within a specific coordinate space.
 * It provides functionality for:
 * - Managing entities organized by layers
 * - Spatial indexing for efficient entity queries
 * - Bounding box management for view operations
 * - Entity selection and highlighting
 * - Memory usage tracking and statistics
 *
 * Layouts use a spatial index (R-tree) for fast entity lookup operations and maintain
 * a hierarchical structure where entities are grouped by layers for efficient rendering
 * and visibility management.
 *
 * @example
 * ```typescript
 * const layout = new AcTrLayout();
 * layout.addEntity(entity);
 * const entities = layout.search(boundingBox);
 * layout.select(['entity1', 'entity2']);
 * ```
 */
export declare class AcTrLayout {
    /** The group that contains all entities in this layout */
    private _group;
    /** Spatial index tree for efficient entity queries */
    private _spatialIndex;
    /** Bounding box containing all entities in this layout */
    private _box;
    /** Map of layers indexed by layer name */
    private _layers;
    /** The flag indicating whether the layout is loaded/activated */
    private _isLoaded;
    /**
     * Creates a new layout instance.
     * Initializes the layout with empty collections and a spatial index.
     */
    constructor();
    /**
     * The internal THREE.js object to use by scene. This is internally used only. Try to avoid using it.
     * @internal
     */
    get internalObject(): THREE.Group<THREE.Object3DEventMap>;
    /**
     * Gets the map of layers in this layout.
     *
     * @returns Map of layer names to layer objects
     */
    get layers(): Map<string, AcTrLayer>;
    /**
     * Gets the bounding box that contains all entities in this layout.
     *
     * @returns The layout's bounding box
     */
    get box(): THREE.Box3;
    /**
     * The flag indicating whether the layout is loaded/activated.
     *
     * @returns The flag indicating whether the layout is loaded/activated.
     */
    get isLoaded(): boolean;
    /**
     * Sets the flag indicating whether the layout is loaded/activated.
     *
     * @param value - The flag indicating whether the layout is loaded/activated.
     */
    set isLoaded(value: boolean);
    /**
     * The visibility of this layout.
     * When set to false, the entire layout and all its contents are hidden.
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * The number of entities stored in this layout.
     * Calculates the total by summing entities across all layers.
     */
    get entityCount(): number;
    /**
     * The statistics of this layout.
     * Provides detailed information about memory usage and entity counts.
     */
    get stats(): AcTrLayoutStats;
    /**
     * Clears all entities from the layout.
     * Removes all layers, resets the bounding box, and clears the spatial index.
     *
     * @returns This layout instance for method chaining
     */
    clear(): this;
    /**
     * Re-render points with latest point style settings.
     * Updates the visual representation of all point entities across all layers.
     *
     * @param displayMode - Input display mode of points
     */
    rerenderPoints(displayMode: number): void;
    /**
     * Return true if the object with the specified object id is intersected with the ray by using raycast.
     *
     * @param objectId - Input object id of object to check for intersection with the ray.
     * @param raycaster - Input raycaster to check intersection
     * @returns True if the object intersects with the ray, false otherwise
     */
    isIntersectWith(objectId: string, raycaster: THREE.Raycaster): boolean;
    /**
     * Add one AutoCAD entity into this layout. If layer group referenced by the entity doesn't exist, create one
     * layer group and add this entity this group.
     *
     * @param entity - Input AutoCAD entity to be added into this layout.
     * @param extendBbox - Input the flag whether to extend the bounding box of the scene by union the bounding box
     * of the specified entity. Defaults to true.
     * @returns This layout instance for method chaining
     *
     * @throws {Error} When entity is missing required objectId or layerName
     */
    addEntity(entity: AcTrEntity, extendBbox?: boolean): this;
    /**
     * Remove the specified entity from this layout.
     *
     * @param objectId - Input the object id of the entity to remove
     * @returns Return true if remove the specified entity successfully. Otherwise, return false.
     */
    removeEntity(objectId: AcDbObjectId): boolean;
    /**
     * Update the specified entity in this layout.
     *
     * @param entity - Input the entity to update
     * @returns Return true if update the specified entity successfully. Otherwise, return false.
     */
    updateEntity(entity: AcTrEntity): boolean;
    /**
     * Gets the layer with the specified name from this layout
     * @param name - Layer name
     * @returns - The layer with the specified name in this layout
     */
    getLayer(name: string): AcTrLayer | undefined;
    /**
     * Adds layer into this layout. If the layer already exist, do nothing.
     *
     * @param name - Input layer name
     * @returns Return added layer or the existing layer in this layout if one layer
     * group already exists in this layout.
     */
    addLayer(info: AcEdLayerInfo): AcTrLayer;
    /**
     * Updates layer information (such as visibility). If the layer doesn't exist, do nothing.
     * @param info - The layer information
     * @returns Returns the updated layer group.
     */
    updateLayer(info: AcEdLayerInfo): AcTrLayer | undefined;
    /**
     * Hover the specified entities.
     * Applies hover highlighting to the entities with the given IDs.
     *
     * @param ids - Array of entity object IDs to hover
     */
    hover(ids: AcDbObjectId[]): void;
    /**
     * Unhover the specified entities.
     * Removes hover highlighting from the entities with the given IDs.
     *
     * @param ids - Array of entity object IDs to unhover
     */
    unhover(ids: AcDbObjectId[]): void;
    /**
     * Select the specified entities.
     * Applies selection highlighting to the entities with the given IDs.
     *
     * @param ids - Array of entity object IDs to select
     */
    select(ids: AcDbObjectId[]): void;
    /**
     * Unselect the specified entities.
     * Removes selection highlighting from the entities with the given IDs.
     *
     * @param ids - Array of entity object IDs to unselect
     */
    unselect(ids: AcDbObjectId[]): void;
    /**
     * Search entities intersected or contained in the specified bounding box.
     * Uses the spatial index for efficient querying of entities within the given bounds.
     *
     * @param box - Input the query bounding box (2D or 3D)
     * @returns Return query results containing entity IDs and their bounds
     */
    search(box: AcGeBox2d | AcGeBox3d): import("../editor").AcEdSpatialQueryResultItemEx[];
    /**
     * Returns all layers that contain renderable entities associated with
     * the specified AutoCAD object ID.
     *
     * In AutoCAD, an INSERT entity may reference multiple child entities that
     * reside on different layers. During rendering, this engine groups entities
     * by layer and assigns each group the INSERT entity's object ID.
     *
     * As a result, a single object ID (typically from an INSERT entity) may
     * correspond to multiple layers, and this method returns all such layers.
     *
     * @param objectId - The AutoCAD object ID to search for (e.g. an INSERT entity ID)
     * @returns An array of layers containing entities associated with the given object ID;
     *          returns an empty array if no matching layers are found
     */
    private getLayersByObjectId;
}
//# sourceMappingURL=AcTrLayout.d.ts.map