import { AcDbCircle, AcGePoint3dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdCommand, AcEdPreviewJig } from '../editor';
export declare class AcApCircleJig extends AcEdPreviewJig<number> {
    private _circle;
    /**
     * Creates a circle jig.
     *
     * @param view - The associated view
     */
    constructor(view: AcEdBaseView, center: AcGePoint3dLike);
    get entity(): AcDbCircle;
    update(radius: number): void;
}
/**
 * Command to create one circle.
 */
export declare class AcApCircleCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApCircleCmd.d.ts.map