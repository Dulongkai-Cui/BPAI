import { AcDbLine, AcGePoint3dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdCommand, AcEdPreviewJig } from '../editor';
export declare class AcApLineJig extends AcEdPreviewJig<AcGePoint3dLike> {
    private _line;
    /**
     * Creates a line jig.
     *
     * @param view - The associated view
     */
    constructor(view: AcEdBaseView, start: AcGePoint3dLike);
    get entity(): AcDbLine;
    update(point: AcGePoint3dLike): void;
}
/**
 * Command to create one line.
 */
export declare class AcApLineCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApLineCmd.d.ts.map