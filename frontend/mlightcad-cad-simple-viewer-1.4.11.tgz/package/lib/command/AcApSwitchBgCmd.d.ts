import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command for switching the drawing background between white and black.
 */
export declare class AcApSwitchBgCmd extends AcEdCommand {
    /**
     * Executes the command to switch the drawing background between white and black.
     *
     * @param context - The application context containing the view
     */
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApSwitchBgCmd.d.ts.map