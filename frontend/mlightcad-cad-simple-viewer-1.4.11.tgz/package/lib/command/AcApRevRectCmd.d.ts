import { AcApContext } from '../app';
import { AcApBaseRevCmd } from './AcApBaseRevCmd';
/**
 * Command to create one revision rectangle.
 */
export declare class AcApRevRectCmd extends AcApBaseRevCmd {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApRevRectCmd.d.ts.map