import { AcApContext } from '../app';
import { AcEdCommand } from '../command';
/**
 * Command to delete selected objects from the drawing.
 */
export declare class AcApEraseCmd extends AcEdCommand {
    constructor();
    /**
     * Executes the command to delete selected objects from the drawing
     *
     * @param context - The current application context
     */
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApEraseCmd.d.ts.map