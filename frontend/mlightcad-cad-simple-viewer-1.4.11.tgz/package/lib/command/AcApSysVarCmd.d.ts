import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command for modifying value of one system variable. All of system variables share
 * this command.
 */
export declare class AcApSysVarCmd extends AcEdCommand {
    constructor();
    /**
     * Executes the command to modify the value of one system variable.
     *
     * @param context - The application context containing the view
     */
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApSysVarCmd.d.ts.map