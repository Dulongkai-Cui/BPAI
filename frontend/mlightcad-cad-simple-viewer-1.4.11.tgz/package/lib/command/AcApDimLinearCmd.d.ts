import { AcDbAlignedDimension, AcDbDatabase, AcGePoint3dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdCommand, AcEdPreviewJig } from '../editor';
export declare class AcApDimJig extends AcEdPreviewJig<AcGePoint3dLike> {
    private _db;
    private _dim;
    private _dimBlockName;
    /**
     * Creates a dimension jig.
     *
     * @param view - The associated view
     */
    constructor(view: AcEdBaseView, db: AcDbDatabase, xline1Point: AcGePoint3dLike, xline2Point: AcGePoint3dLike);
    get entity(): AcDbAlignedDimension;
    update(point: AcGePoint3dLike): void;
    end(): void;
    private calculateAngle;
}
/**
 * Command to create one aligned dimension.
 */
export declare class AcApDimLinearCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
    private getAvaiableDimBlockName;
}
//# sourceMappingURL=AcApDimLinearCmd.d.ts.map