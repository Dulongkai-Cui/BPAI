import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Registers a cleanup function to be called when the Clear Measurements command
 * runs. Used for CAD transient entities, canvas overlays, and viewChanged
 * listeners that are not managed by the htmlTransientManager.
 */
export declare function registerMeasurementCleanup(fn: () => void): void;
export declare class AcApClearMeasurementsCmd extends AcEdCommand {
    constructor();
    execute(_context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApClearMeasurementsCmd.d.ts.map