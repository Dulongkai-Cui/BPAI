import { AcApContext } from '../app';
import { AcApBaseRevCmd } from './AcApBaseRevCmd';
/**
 * Command to create one revision circle.
 */
export declare class AcApRevCircleCmd extends AcApBaseRevCmd {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApRevCircleCmd.d.ts.map