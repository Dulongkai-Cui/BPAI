import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command that measures the angle between two arms sharing a common vertex.
 *
 * Prompts the user to pick three world points: the vertex, a point on the
 * first arm, and a point on the second arm. After the second arm is confirmed,
 * transient CAD lines are added for both arms and persistent DOM overlays
 * (arc canvas + dots + badge) are placed via {@link AcTrHtmlTransientManager}.
 */
export declare class AcApMeasureAngleCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApMeasureAngleCmd.d.ts.map