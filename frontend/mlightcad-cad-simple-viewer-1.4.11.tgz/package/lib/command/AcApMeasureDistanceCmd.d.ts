import { AcCmColor, AcDbLine, AcGePoint3dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdCommand, AcEdPreviewJig } from '../editor';
/**
 * Preview jig for the distance measurement command.
 *
 * Renders a live rubber-band line from the fixed first point to the current
 * cursor position. The badge showing the live distance is rendered by the
 * jig itself and is removed when the jig ends — it is intentionally short-lived
 * and intrinsic to the interactive input UX.
 */
export declare class AcApMeasureDistanceJig extends AcEdPreviewJig<AcGePoint3dLike> {
    private _line;
    private _p1;
    private _view;
    private _badge;
    constructor(view: AcEdBaseView, p1: AcGePoint3dLike, color: AcCmColor);
    get entity(): AcDbLine;
    update(p2: AcGePoint3dLike): void;
    end(): void;
}
/**
 * Command that measures the straight-line distance between two points.
 *
 * Prompts the user to pick two world points, then registers a transient CAD
 * line between them. Persistent DOM overlays (dots + badge) are placed via
 * {@link AcTrHtmlTransientManager} using CSS2DObject, so they track zoom/pan
 * automatically without manual viewChanged listeners.
 */
export declare class AcApMeasureDistanceCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApMeasureDistanceCmd.d.ts.map