import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command that measures the area of a polygon drawn by the user.
 *
 * The user clicks successive vertices; after each click the canvas overlay
 * updates with a semi-transparent blue fill and a dashed outline. The polygon
 * auto-closes when the user clicks near the first vertex (14 px threshold),
 * clicks near the last vertex, or draws a segment that crosses an existing
 * edge — matching AutoCAD's area measurement behaviour. Pressing ESC/Enter
 * also finalises the polygon.
 *
 * Persistent overlays are placed via {@link AcTrHtmlTransientManager} for dots
 * and badge. The filled area canvas is managed with a viewChanged listener
 * cleaned up via {@link registerMeasurementCleanup}.
 */
export declare class AcApMeasureAreaCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApMeasureAreaCmd.d.ts.map