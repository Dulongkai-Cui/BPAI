import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Base command for revision commands.
 */
export declare class AcApBaseRevCmd extends AcEdCommand {
    /**
     * The layer name for revision
     */
    private _revisionLayer?;
    /**
     * The previous current layer
     */
    private _previousLayer?;
    /**
     * The previous current entity color
     */
    private _previousCecolor?;
    /**
     * The previous current entity line weight
     */
    private _previousCelweight?;
    /**
     * The flag whether to show entity draw style toolbar
     */
    private _isShowEntityDrawStyleToolbar;
    constructor();
    /**
     * Returns true if it is to show entity draw style toolbar
     */
    get isShowEntityDrawStyleToolbar(): boolean;
    set isShowEntityDrawStyleToolbar(value: boolean);
    protected onCommandWillStart(context: AcApContext): void;
    protected onCommandEnded(context: AcApContext): void;
}
//# sourceMappingURL=AcApBaseRevCmd.d.ts.map