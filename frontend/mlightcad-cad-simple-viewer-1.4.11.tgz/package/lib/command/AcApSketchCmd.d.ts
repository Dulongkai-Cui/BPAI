import { AcDbPolyline, AcGePoint2d, AcGePoint2dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdPreviewJig } from '../editor';
import { AcApBaseRevCmd } from './AcApBaseRevCmd';
export declare class AcApSketchJig extends AcEdPreviewJig<AcGePoint2dLike> {
    private _polyline;
    private _points;
    private _lastPoint;
    /**
     * Creates a sketch jig.
     *
     * @param view - The associated view
     * @param start - The first point
     */
    constructor(view: AcEdBaseView, start: AcGePoint2dLike);
    get entity(): AcDbPolyline;
    /**
     * Gets all accumulated points
     */
    get points(): AcGePoint2d[];
    update(currentPoint: AcGePoint2dLike): void;
}
/**
 * Command to create a sketch line using polyline.
 * After specifying the first point, continuously tracks mouse movement
 * and adds points to the polyline until the user specifies the second point.
 */
export declare class AcApSketchCmd extends AcApBaseRevCmd {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApSketchCmd.d.ts.map