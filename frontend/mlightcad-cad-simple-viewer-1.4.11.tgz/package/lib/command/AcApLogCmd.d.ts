import { AcApContext } from '../app';
import { AcEdCommand } from '../command';
/**
 * This is an internal command used to log some debug information in console.
 * @internal
 */
export declare class AcApLogCmd extends AcEdCommand {
    execute(context: AcApContext): Promise<void>;
    private printSelectionSet;
    private printStats;
    private printPerformanceData;
}
//# sourceMappingURL=AcApLogCmd.d.ts.map