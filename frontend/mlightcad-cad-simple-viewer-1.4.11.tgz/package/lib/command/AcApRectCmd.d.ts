import { AcDbPolyline, AcGePoint2dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdCommand, AcEdPreviewJig } from '../editor';
export declare class AcApRectJig extends AcEdPreviewJig<AcGePoint2dLike> {
    private _rect;
    private _firstPoint;
    /**
     * Creates a line jig.
     *
     * @param view - The associated view
     */
    constructor(view: AcEdBaseView, start: AcGePoint2dLike);
    get entity(): AcDbPolyline;
    update(secondPoint: AcGePoint2dLike): void;
}
/**
 * Command to create one rectangle.
 */
export declare class AcApRectCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApRectCmd.d.ts.map