import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command to create one mtext entity.
 */
export declare class AcApMTextCmd extends AcEdCommand {
    private readonly mtextEditor;
    constructor();
    execute(context: AcApContext): Promise<void>;
    private pixelsToWorldY;
}
//# sourceMappingURL=AcApMTextCmd.d.ts.map