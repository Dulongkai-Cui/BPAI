import { AcApContext } from '../app';
import { AcApBaseRevCmd } from './AcApBaseRevCmd';
/**
 * Command for switching the visibility of the current layer.
 */
export declare class AcApRevVisibilityCmd extends AcApBaseRevCmd {
    constructor();
    /**
     * Executes the command to switch the visibility of the current layer.
     *
     * @param context - The application context containing the view
     */
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApRevVisibilityCmd.d.ts.map