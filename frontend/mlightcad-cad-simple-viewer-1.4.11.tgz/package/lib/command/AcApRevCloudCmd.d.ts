import { AcDbPolyline, AcGePoint2dLike } from '@mlightcad/data-model';
import { AcApContext } from '../app';
import { AcEdBaseView, AcEdPreviewJig } from '../editor';
import { AcApBaseRevCmd } from './AcApBaseRevCmd';
export declare class AcApRevCloudJig extends AcEdPreviewJig<AcGePoint2dLike> {
    private _cloud;
    private _firstPoint;
    private _view;
    /**
     * Creates a cloud line jig.
     *
     * @param view - The associated view
     * @param start - The first corner point
     */
    constructor(view: AcEdBaseView, start: AcGePoint2dLike);
    get entity(): AcDbPolyline;
    update(secondPoint: AcGePoint2dLike): void;
}
/**
 * Command to create a revision cloud (cloud line) in rectangular shape.
 */
export declare class AcApRevCloudCmd extends AcApBaseRevCmd {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApRevCloudCmd.d.ts.map