import { AcApContext } from '../app';
import { AcEdCommand } from '../editor';
/**
 * Command that measures the length of an arc on an existing circle or arc entity.
 *
 * Uses a two-phase pick flow that mirrors AutoCAD's arc-length measurement:
 *
 * 1. **Phase 1 — entity snap**: The user hovers over a circle or arc in the
 *    drawing. A square snap indicator appears on the circumference and the
 *    entity geometry is captured. Clicking confirms the start point.
 *
 * 2. **Phase 2 — end point**: The same square indicator follows the cursor,
 *    always locked to the captured circle. A canvas overlay draws the shorter
 *    arc between the start and current position in real time, together with a
 *    live badge showing the arc length.
 *
 * Persistent overlays are placed via {@link AcTrHtmlTransientManager} for dots
 * and badge. The arc canvas is managed with a viewChanged listener cleaned up
 * via {@link registerMeasurementCleanup}.
 */
export declare class AcApMeasureArcCmd extends AcEdCommand {
    constructor();
    execute(context: AcApContext): Promise<void>;
}
//# sourceMappingURL=AcApMeasureArcCmd.d.ts.map