import { AcDbObjectId } from '@mlightcad/data-model';
import { AcTrGroup } from '@mlightcad/three-renderer';
import { AcEdSpatialQueryResultItem, AcEdSpatialQueryResultItemEx } from '../editor/view';
import { AcTrSpatialIndex, AcTrSpatialIndexBBox } from './AcTrSpatialIndex';
/**
 * A two-level (hierarchical) spatial index designed for complex CAD
 * scene structures such as blocks, groups, layers, or nested entities.
 *
 * The index consists of:
 *
 * 1. A first-level spatial index that stores coarse bounding boxes
 *    (AcEdSpatialQueryResultItem) and maps each result to an `id`.
 *
 * 2. A second-level map from `id` to another spatial index, which
 *    contains more detailed spatial data for that specific entity,
 *    block, or group.
 *
 * Spatial queries are executed in two phases:
 * - First, the query is performed against the root spatial index to
 *   find candidate items.
 * - Then, for each candidate, the corresponding second-level spatial
 *   index (if present) is queried for more precise results.
 * - Results from both levels are merged into a single query result.
 *
 * This design allows:
 * - Mixing different spatial index implementations (e.g. R-tree and
 *   linear scan) at different hierarchy levels
 * - Efficient querying of large, nested CAD datasets
 * - Lazy or selective construction of fine-grained spatial indexes
 *
 * This class is particularly suitable for CAD viewers and editors
 * where entities are grouped hierarchically but still require fast
 * spatial queries such as selection, picking, and hit-testing.
 */
export declare class AcTrHierarchicalSpatialIndex implements AcTrSpatialIndex {
    static THRESHOLD: number;
    private readonly rootIndex;
    private readonly childIndexes;
    constructor(rootIndex?: AcTrSpatialIndex<AcEdSpatialQueryResultItem>);
    /** Register second-level index for an id */
    setChildIndex(id: string, index: AcTrSpatialIndex): void;
    /** Remove second-level index */
    removeChildIndex(id: string): void;
    insert(item: AcEdSpatialQueryResultItem): void;
    load(items: readonly AcEdSpatialQueryResultItem[]): void;
    remove(item: AcEdSpatialQueryResultItem, equals?: (a: AcEdSpatialQueryResultItem, b: AcEdSpatialQueryResultItem) => boolean): void;
    removeById(id: AcDbObjectId): void;
    clear(): void;
    search(bbox: AcTrSpatialIndexBBox): AcEdSpatialQueryResultItemEx[];
    collides(bbox: AcTrSpatialIndexBBox): boolean;
    all(): AcEdSpatialQueryResultItem[];
    createChildIndex(group: AcTrGroup): AcTrSpatialIndex<AcEdSpatialQueryResultItem> | undefined;
}
//# sourceMappingURL=AcTrHierarchicalSpatialIndex.d.ts.map