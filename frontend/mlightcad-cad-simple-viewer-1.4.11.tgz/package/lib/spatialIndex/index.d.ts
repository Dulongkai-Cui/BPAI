export * from './AcTrHierarchicalSpatialIndex';
export * from './AcTrSpatialIndex';
//# sourceMappingURL=index.d.ts.map