import { AcDbObjectId } from '@mlightcad/data-model';
import { AcEdSpatialQueryResultItem } from '../editor/view';
import { AcTrSpatialIndex, AcTrSpatialIndexBBox } from './AcTrSpatialIndex';
export declare class AcTrRBushSpatialIndex implements AcTrSpatialIndex {
    private readonly tree;
    private readonly idMap;
    constructor(maxEntries?: number);
    insert(item: AcEdSpatialQueryResultItem): void;
    load(items: readonly AcEdSpatialQueryResultItem[]): void;
    remove(item: AcEdSpatialQueryResultItem, equals?: (a: AcEdSpatialQueryResultItem, b: AcEdSpatialQueryResultItem) => boolean): void;
    removeById(id: AcDbObjectId): void;
    clear(): void;
    search(bbox: AcTrSpatialIndexBBox): AcEdSpatialQueryResultItem[];
    collides(bbox: AcTrSpatialIndexBBox): boolean;
    all(): AcEdSpatialQueryResultItem[];
}
//# sourceMappingURL=AcTrRBushSpatialIndex.d.ts.map