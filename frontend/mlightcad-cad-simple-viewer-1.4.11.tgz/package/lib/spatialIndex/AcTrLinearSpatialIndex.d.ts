import { AcDbObjectId } from '@mlightcad/data-model';
import { AcEdSpatialQueryResultItem } from '../editor/view';
import { AcTrSpatialIndex, AcTrSpatialIndexBBox } from './AcTrSpatialIndex';
/**
 * A simple spatial index implementation that performs linear scanning
 * over all stored bounding boxes.
 *
 * This index does not build any spatial acceleration structure. All
 * spatial queries are executed by iterating through the full item list
 * and testing bounding-box intersection one by one.
 *
 * Typical use cases:
 * - Small datasets where index construction overhead is unnecessary
 * - Highly dynamic data with frequent insert/remove operations
 * - Debugging or validation of spatial query correctness
 * - Fallback implementation when spatial indexing is not available
 *
 * Time complexity:
 * - Insert / Remove: O(1)
 * - Search / Collides: O(n)
 *
 * This implementation is memory-efficient and predictable, but does
 * not scale well for large numbers of items.
 */
export declare class AcTrLinearSpatialIndex implements AcTrSpatialIndex {
    /** Items indexed by object id */
    private items;
    insert(item: AcEdSpatialQueryResultItem): void;
    load(items: readonly AcEdSpatialQueryResultItem[]): void;
    remove(item: AcEdSpatialQueryResultItem): void;
    removeById(id: AcDbObjectId): void;
    clear(): void;
    search(bbox: AcTrSpatialIndexBBox): AcEdSpatialQueryResultItem[];
    collides(bbox: AcTrSpatialIndexBBox): boolean;
    all(): AcEdSpatialQueryResultItem[];
}
//# sourceMappingURL=AcTrLinearSpatialIndex.d.ts.map