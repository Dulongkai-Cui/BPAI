import { AcApContext } from '../app/AcApContext';
import { AcEdCommandStack } from '../editor/command/AcEdCommandStack';
import { AcApPlugin } from './AcApPlugin';
/**
 * Plugin manager for dynamically loading and unloading plugins.
 *
 * This class manages the lifecycle of plugins, including:
 * - Loading plugins and calling their `onLoad` hooks
 * - Unloading plugins and calling their `onUnload` hooks
 * - Providing access to the application context and command manager
 *
 * Plugins are responsible for cleaning up their own registered commands
 * in the `onUnload` hook using `commandManager.removeCmd()`.
 *
 * @example
 * ```typescript
 * const pluginManager = AcApDocManager.instance.pluginManager;
 *
 * // Load a plugin
 * const myPlugin = new MyPlugin();
 * await pluginManager.loadPlugin(myPlugin);
 *
 * // Unload a plugin
 * await pluginManager.unloadPlugin('MyPlugin');
 *
 * // Check if a plugin is loaded
 * if (pluginManager.isPluginLoaded('MyPlugin')) {
 *   log.info('Plugin is loaded');
 * }
 *
 * // Get all loaded plugins
 * const loadedPlugins = pluginManager.getLoadedPlugins();
 * ```
 */
export declare class AcApPluginManager {
    /** Map of loaded plugins by name */
    private _plugins;
    /** The application context */
    private _context;
    /** The command manager */
    private _commandManager;
    /**
     * Creates a new plugin manager.
     *
     * @param context - The application context
     * @param commandManager - The command manager for plugin command registration
     */
    constructor(context: AcApContext, commandManager: AcEdCommandStack);
    /**
     * Loads a plugin and calls its `onLoad` hook.
     *
     * If the plugin is already loaded, this method will throw an error.
     * The plugin's `onLoad` method will be called with the context and command manager.
     *
     * @param plugin - The plugin instance to load
     * @throws {Error} If a plugin with the same name is already loaded
     *
     * @example
     * ```typescript
     * const plugin = new MyPlugin();
     * await pluginManager.loadPlugin(plugin);
     * ```
     */
    loadPlugin(plugin: AcApPlugin): Promise<void>;
    /**
     * Unloads a plugin and calls its `onUnload` hook.
     *
     * This method will:
     * 1. Call the plugin's `onUnload` hook (plugins should clean up their commands here)
     * 2. Remove the plugin from the loaded plugins map
     *
     * @param pluginName - The name of the plugin to unload
     * @returns `true` if the plugin was successfully unloaded, `false` if it wasn't loaded
     *
     * @example
     * ```typescript
     * const success = await pluginManager.unloadPlugin('MyPlugin');
     * if (success) {
     *   log.info('Plugin unloaded successfully');
     * }
     * ```
     */
    unloadPlugin(pluginName: string): Promise<boolean>;
    /**
     * Checks if a plugin is currently loaded.
     *
     * @param pluginName - The name of the plugin to check
     * @returns `true` if the plugin is loaded, `false` otherwise
     */
    isPluginLoaded(pluginName: string): boolean;
    /**
     * Gets information about a loaded plugin.
     *
     * @param pluginName - The name of the plugin
     * @returns The plugin instance if loaded, `undefined` otherwise
     */
    getPlugin(pluginName: string): AcApPlugin | undefined;
    /**
     * Gets all currently loaded plugins.
     *
     * @returns Array of loaded plugin names
     */
    getLoadedPlugins(): string[];
    /**
     * Unloads all currently loaded plugins.
     *
     * This method calls `unloadPlugin` for each loaded plugin.
     *
     * @example
     * ```typescript
     * await pluginManager.unloadAllPlugins();
     * ```
     */
    unloadAllPlugins(): Promise<void>;
    /**
     * Loads multiple plugins from a configuration array.
     *
     * This method accepts an array of plugin instances or plugin factory functions.
     * Factory functions are useful when you want to create plugin instances lazily.
     *
     * @param plugins - Array of plugin instances or factory functions that return plugin instances
     * @param options - Optional configuration for loading behavior
     * @param options.continueOnError - If true, continue loading other plugins even if one fails (default: false)
     * @returns Promise that resolves to an object containing successful and failed plugin loads
     *
     * @example
     * ```typescript
     * // Load plugins from instances
     * await pluginManager.loadPluginsFromConfig([
     *   new MyPlugin1(),
     *   new MyPlugin2()
     * ]);
     *
     * // Load plugins from factory functions
     * await pluginManager.loadPluginsFromConfig([
     *   () => new MyPlugin1(),
     *   () => new MyPlugin2()
     * ]);
     *
     * // Continue loading even if some fail
     * const result = await pluginManager.loadPluginsFromConfig(
     *   [new Plugin1(), new Plugin2()],
     *   { continueOnError: true }
     * );
     * log.info('Loaded:', result.loaded);
     * log.info('Failed:', result.failed);
     * ```
     */
    loadPluginsFromConfig(plugins: Array<AcApPlugin | (() => AcApPlugin)>, options?: {
        continueOnError?: boolean;
    }): Promise<{
        loaded: string[];
        failed: Array<{
            name: string;
            error: Error;
        }>;
    }>;
    /**
     * Loads plugins from a folder using dynamic imports.
     *
     * This method scans a folder for plugin files and dynamically imports them.
     * It expects each plugin file to export a default export that is either:
     * - A plugin instance
     * - A plugin class (constructor function)
     * - A factory function that returns a plugin instance
     *
     * @param folderPath - Path to the folder containing plugin files (relative to the base URL)
     * @param options - Optional configuration for loading behavior
     * @param options.pattern - Glob pattern to match plugin files (default: '*.js' or '*.ts')
     * @param options.continueOnError - If true, continue loading other plugins even if one fails (default: false)
     * @param options.pluginList - Optional array of specific plugin file names to load (if not provided, attempts to auto-discover)
     * @returns Promise that resolves to an object containing successful and failed plugin loads
     *
     * @example
     * ```typescript
     * // Load all plugins from a folder (requires plugin list or manifest)
     * await pluginManager.loadPluginsFromFolder('./plugins', {
     *   pluginList: ['MyPlugin1.js', 'MyPlugin2.js']
     * });
     *
     * // Or with continue on error
     * const result = await pluginManager.loadPluginsFromFolder('./plugins', {
     *   pluginList: ['Plugin1.js', 'Plugin2.js'],
     *   continueOnError: true
     * });
     * ```
     *
     * @remarks
     * In browser environments, you typically need to provide a list of plugin files
     * to load, as there's no direct way to list directory contents. You can:
     * 1. Provide a `pluginList` array with specific file names
     * 2. Create a manifest file that lists all plugins
     * 3. Use a build-time tool to generate the plugin list
     */
    loadPluginsFromFolder(folderPath: string, options?: {
        pluginList?: string[];
        continueOnError?: boolean;
    }): Promise<{
        loaded: string[];
        failed: Array<{
            name: string;
            error: Error;
        }>;
    }>;
}
//# sourceMappingURL=AcApPluginManager.d.ts.map