import { AcApContext } from '../app/AcApContext';
import { AcEdCommandStack } from '../editor/command/AcEdCommandStack';
import { AcApPlugin } from './AcApPlugin';
/**
 * Example plugin implementation.
 */
export declare class AcApExamplePlugin implements AcApPlugin {
    name: string;
    version: string;
    description: string;
    private registeredCommands;
    /**
     * Called when the plugin is loaded.
     * Register custom commands here.
     */
    onLoad(_context: AcApContext, commandManager: AcEdCommandStack): void;
    /**
     * Called when the plugin is unloaded.
     * Clean up registered commands and other resources here.
     */
    onUnload(_context: AcApContext, commandManager: AcEdCommandStack): void;
}
//# sourceMappingURL=AcApPluginExample.d.ts.map