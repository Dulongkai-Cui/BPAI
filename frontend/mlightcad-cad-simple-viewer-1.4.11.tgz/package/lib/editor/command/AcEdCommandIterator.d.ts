import { AcEdCommand } from './AcEdCommand';
import { AcEdCommandGroup } from './AcEdCommandStack';
/**
 * Represents the type of item returned by command iterator.
 */
export interface AcEdCommandIteratorItem {
    commandGroup: string;
    command: AcEdCommand;
}
/**
 * This class allows you to traverse the chain of command groups that are registered with AutoCAD and
 * obtain information about the groups and the AcEdCommand objects within them.
 */
export declare class AcEdCommandIterator implements IterableIterator<AcEdCommandIteratorItem> {
    private _index;
    private _commands;
    constructor(commandGroups: AcEdCommandGroup[]);
    [Symbol.iterator](): IterableIterator<AcEdCommandIteratorItem>;
    /**
     * Return command object the iterator currently points to. If the iterator is at the beginning, then the
     * first object is returned. If the iterator has already gone past the last entry, then null is returned.
     */
    get command(): AcEdCommand<{}> | null;
    /**
     * Return the name of the command object the iterator currently points to. If the iterator is at the
     * beginning, then the first object is returned. If the iterator has already gone past the last entry,
     * then null is returned.
     */
    get commandGroup(): string | null;
    /**
     * Increment the iterator to the next entry.
     * @returns Return the next entry
     */
    next(): IteratorResult<AcEdCommandIteratorItem, null>;
}
//# sourceMappingURL=AcEdCommandIterator.d.ts.map