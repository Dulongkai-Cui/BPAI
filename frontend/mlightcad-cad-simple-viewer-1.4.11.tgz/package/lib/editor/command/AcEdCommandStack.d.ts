import { AcEdOpenMode } from '../view';
import { AcEdCommand } from './AcEdCommand';
import { AcEdCommandIterator, AcEdCommandIteratorItem } from './AcEdCommandIterator';
/**
 * Interface representing a command group in the command stack.
 * Groups commands by name and provides maps for both global and local command lookups.
 */
export interface AcEdCommandGroup {
    /** The name of the command group */
    groupName: string;
    /** Map of commands indexed by their global names */
    commandsByGlobalName: Map<string, AcEdCommand>;
    /** Map of commands indexed by their local names */
    commandsByLocalName: Map<string, AcEdCommand>;
}
/**
 * The class to create, define, and register command objects.
 *
 * It is used to manages all command registration and lookup functionality.
 * Commands are organized into groups, with system commands (ACAD) and user commands (USER)
 * being the default groups.
 *
 * @example
 * ```typescript
 * const commandStack = AcApDocManager.instance.commandManager;
 * commandStack.addCommand('USER', 'MYCOMMAND', 'MYCOMMAND', myCommandInstance);
 * const command = commandStack.lookupGlobalCmd('MYCOMMAND');
 * ```
 */
export declare class AcEdCommandStack {
    /** The name of the system command group */
    static SYSTEMT_COMMAND_GROUP_NAME: string;
    /** The name of the default user command group */
    static DEFAUT_COMMAND_GROUP_NAME: string;
    /** Array of all command groups in the stack */
    private _commandsByGroup;
    /** Reference to the system command group */
    private _systemCommandGroup;
    /** Reference to the default user command group */
    private _defaultCommandGroup;
    /**
     * Private constructor to enforce singleton pattern.
     * Initializes the command stack with system and default command groups.
     */
    constructor();
    /**
     * Adds a command to the specified command group.
     *
     * @param cmdGroupName - The name of the command group. If empty, uses the default group.
     * @param cmdGlobalName - The global (untranslated) name of the command. Must be unique within the group.
     * @param cmdLocalName - The local (translated) name of the command. Defaults to global name if empty.
     * @param cmd - The command object to add to the stack.
     *
     * @throws {Error} When the global name is empty or when a command with the same name already exists
     *
     * @example
     * ```typescript
     * commandStack.addCommand('USER', 'LINE', 'ligne', new LineCommand());
     * ```
     */
    addCommand(cmdGroupName: string, cmdGlobalName: string, cmdLocalName: string, cmd: AcEdCommand): void;
    /**
     * Return an iterator that can be used to traverse all of command objects in this command stack
     * (that is, the iterator iterates through all commands in all groups).
     *
     * @returns Return an iterator that can be used to traverse all of command objects in this command
     * stack.
     */
    iterator(): AcEdCommandIterator;
    /**
     * Fuzzy search for commands by prefix using the command iterator.
     *
     * This method iterates through all commands in all command groups and returns those
     * whose global or local names start with the provided prefix. The search is case-insensitive.
     * If a mode is specified, only commands compatible with that mode are returned.
     * Higher value modes are compatible with lower value modes.
     *
     * @param prefix - The prefix string to search for. Case-insensitive.
     * @param mode - Optional access mode to filter commands. Only commands compatible with this mode are returned.
     * @returns An array of objects containing matched commands and their corresponding group names.
     *
     * @example
     * ```typescript
     * const matches = commandStack.searchCommandsByPrefix('LI', AcEdOpenMode.Write);
     * matches.forEach(item => {
     *   console.log(item.groupName, item.command.globalName);
     * });
     * ```
     */
    searchCommandsByPrefix(prefix: string, mode?: AcEdOpenMode): AcEdCommandIteratorItem[];
    /**
     * Search through all of the global and untranslated names in all of the command groups in the command
     * stack starting at the top of the stack trying to find a match with cmdName. If a match is found, the
     * matched AcEdCommand object is returned. Otherwise undefined is returned to indicate that the command
     * could not be found. If more than one command of the same name is present in the command stack (that
     * is, in separate command groups), then the first one found is used.
     *
     * If a mode is specified, the command is only returned if it is compatible with that mode.
     * Higher value modes are compatible with lower value modes.
     *
     * @param cmdName - Input the command name to search for
     * @param mode - Optional access mode to check compatibility. Only returns the command if it's compatible with this mode.
     * @returns Return the matched AcEdCommand object if a match is found and compatible with the mode. Otherwise, return undefined.
     */
    lookupGlobalCmd(cmdName: string, mode?: AcEdOpenMode): AcEdCommand<{}> | undefined;
    /**
     * Search through all of the local and translated names in all of the command groups in the command stack
     * starting at the top of the stack trying to find a match with cmdName. If a match is found, the matched
     * AcEdCommand object is returned. Otherwise undefined is returned to indicate that the command could not
     * be found. If more than one command of the same name is present in the command stack (that is, in
     * separate command groups), then the first one found is used.
     *
     * If a mode is specified, the command is only returned if it is compatible with that mode.
     * Higher value modes are compatible with lower value modes.
     *
     * @param cmdName - Input the command name to search for
     * @param mode - Optional access mode to check compatibility. Only returns the command if it's compatible with this mode.
     * @returns Return the matched AcEdCommand object if a match is found and compatible with the mode. Otherwise, return undefined.
     */
    lookupLocalCmd(cmdName: string, mode?: AcEdOpenMode): AcEdCommand<{}> | undefined;
    /**
     * Remove the command with the global and untranslated name `cmdGlobalName` from the `cmdGroupName`
     * command group. Return true if successful. Return false if no command with the global and untranslated
     * name `cmdGlobalName` is found in the `cmdGroupName` command group.
     *
     * @param cmdGroupName - Input the name of the command group containing the command to be removed
     * @param cmdGlobalName - Input the command name which is to be removed from cmdGroupName
     * @returns Return true if successful. Return false if no command with the global and untranslated
     * name `cmdGlobalName` is found in the `cmdGroupName` command group.
     */
    removeCmd(cmdGroupName: string, cmdGlobalName: string): boolean;
    /**
     * Remove the command group with the name `GroupName` from the command stack and delete the command group
     * dictionary object and all the AcEdCommand objects stored within it.
     *
     * @param groupName - Input the name of the command group to be removed from the command stack.
     * @returns Return true if successful. Return false if no command group is found with the name `GroupName`.
     */
    removeGroup(groupName: string): boolean;
    /**
     * Removes all of registered commands
     */
    removeAll(): void;
    /**
     * Checks if a document mode is compatible with a command's required mode.
     *
     * Higher value modes are compatible with lower value modes.
     * - Write mode (8) is compatible with Review (4) and Read (0) commands
     * - Review mode (4) is compatible with Read (0) commands
     * - Read mode (0) is only compatible with Read (0) commands
     *
     * @param documentMode - The mode of the document
     * @param commandMode - The mode required by the command
     * @returns True if the document mode is compatible with the command mode
     */
    private isModeCompatible;
}
//# sourceMappingURL=AcEdCommandStack.d.ts.map