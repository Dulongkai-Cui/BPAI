import { AcEdBaseView } from '../view';
/**
 * Enumeration of cursor types available in the CAD editor.
 *
 * These cursor types provide visual feedback to users about the current
 * operation mode or expected input type. Each cursor has a specific
 * appearance and is used in different contexts.
 *
 * @example
 * ```typescript
 * // Set crosshair cursor for precise point input
 * editor.setCursor(AcEdCorsorType.Crosshair);
 *
 * // Set grab cursor for pan operations
 * editor.setCursor(AcEdCorsorType.Grab);
 *
 * // Restore default cursor
 * editor.setCursor(AcEdCorsorType.NoSpecialCursor);
 * ```
 */
export declare enum AcEdCorsorType {
    /** No special cursor - uses browser default */
    NoSpecialCursor = -1,
    /** Crosshair cursor for precise point selection */
    Crosshair = 0,
    /** Rectangle cursor for area selection */
    RectCursor = 1,
    /** Rubber band cursor for dynamic drawing */
    RubberBand = 2,
    /** Non-rotated cursor */
    NotRotated = 3,
    /** Target box cursor for object snapping */
    TargetBox = 4,
    /** Rotated crosshair cursor */
    RotatedCrosshair = 5,
    /** Crosshair that doesn't rotate with view */
    CrosshairNoRotate = 6,
    /** Invisible cursor for hiding cursor */
    Invisible = 7,
    /** Entity selection cursor */
    EntitySelect = 8,
    /** Parallelogram cursor for skewed operations */
    Parallelogram = 9,
    /** Entity select cursor without perspective */
    EntitySelectNoPersp = 10,
    /** Cursor for pick-first or grips operations */
    PkfirstOrGrips = 11,
    /** Dashed crosshair cursor */
    CrosshairDashed = 12,
    /** Grab/hand cursor for panning */
    Grab = 13
}
/**
 * Manages cursor appearance and behavior for the CAD editor.
 *
 * This class creates and applies custom cursors to HTML elements,
 * providing visual feedback for different CAD operations. It supports
 * both built-in browser cursors and custom SVG-based cursors.
 *
 * The cursor manager maintains a cache of cursor definitions to avoid
 * recreating them repeatedly, improving performance.
 */
export declare class AcEdCursorManager {
    /** The view associated with the cursor manager */
    private _view;
    /** The current curos type in the associated view */
    private _currentCursor;
    /** Cache of cursor definitions mapped by cursor type */
    private _cursorMap;
    /**
     * Creates a new cursor manager instance.
     * Initializes the cursor and creates default cursor definitions.
     * @param view - The view associated with the cursor manager
     */
    constructor(view: AcEdBaseView);
    /**
     * The current cursor type for the associated view.
     */
    get currentCursor(): AcEdCorsorType;
    /**
     * Sets the current cursor for the associated view.
     *
     * @param cursorType - The type of cursor to set
     */
    setCursor(cursorType: AcEdCorsorType): void;
    /**
     * Encodes an SVG string into a CSS cursor URL.
     *
     * This method converts SVG markup into a data URI that can be used
     * as a CSS cursor value, with specified hotspot coordinates.
     *
     * @param svgString - The SVG markup as a string
     * @param xOffset - X coordinate of the cursor hotspot
     * @param yOffset - Y coordinate of the cursor hotspot
     * @returns CSS cursor string in url() format
     *
     * @example
     * ```typescript
     * const svgCursor = '<svg width="20" height="20">...</svg>';
     * const cursorUrl = cursorManager.encodeSvgToCursor(svgCursor, 10, 10);
     * element.style.cursor = cursorUrl;
     * ```
     */
    encodeSvgToCursor(svgString: string, xOffset: number, yOffset: number): string;
    /**
     * Create one svg icon with one rectangle plus two cross lines
     * @param rectSize Input the width and height of rectangle
     * @param crossLineLength Input the length of one cross line
     * @param lineColor Input line color
     * @returns Return svg string of the icon
     */
    private createRectCrossIcon;
}
//# sourceMappingURL=AcEdCursorManager.d.ts.map