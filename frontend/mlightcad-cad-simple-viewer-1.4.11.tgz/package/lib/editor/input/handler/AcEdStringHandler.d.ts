import { AcEdPromptStringOptions } from '../prompt/AcEdPromptStringOptions';
import { AcEdInputHandler } from './AcEdInputHandler';
/**
 * Validates string input according to {@link AcEdPromptStringOptions}.
 * Supports empty string rules and maximum length.
 */
export declare class AcEdStringHandler implements AcEdInputHandler<string> {
    private options;
    constructor(options: AcEdPromptStringOptions);
    parse(value: string): string | null;
}
//# sourceMappingURL=AcEdStringHandler.d.ts.map