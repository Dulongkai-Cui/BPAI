import { AcEdPromptNumericalOptions } from '../prompt/AcEdPromptNumericalOptions';
import { AcEdInputHandler } from './AcEdInputHandler';
/**
 * Handles validation and parsing of numerical user input.
 */
export declare class AcEdNumericalHandler implements AcEdInputHandler<number> {
    protected options: AcEdPromptNumericalOptions;
    constructor(options: AcEdPromptNumericalOptions);
    parse(value: string): number | null;
}
//# sourceMappingURL=AcEdNumericalHandler.d.ts.map