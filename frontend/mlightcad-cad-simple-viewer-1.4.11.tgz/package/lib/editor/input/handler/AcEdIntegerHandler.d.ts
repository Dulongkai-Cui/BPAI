import { AcEdPromptIntegerOptions } from '../prompt/AcEdPromptIntegerOptions';
import { AcEdNumericalHandler } from './AcEdNumericalHandler';
/**
 * Handles validation and parsing of integer user input.
 */
export declare class AcEdIntegerHandler extends AcEdNumericalHandler {
    protected options: AcEdPromptIntegerOptions;
    constructor(options: AcEdPromptIntegerOptions);
    parse(value: string): number | null;
}
//# sourceMappingURL=AcEdIntegerHandler.d.ts.map