import { AcEdNumericalHandler } from './AcEdNumericalHandler';
/**
 * Validates distance input.
 * Distances must be numeric and normally non-negative (AutoCAD behavior).
 */
export declare class AcEdDistanceHandler extends AcEdNumericalHandler {
}
//# sourceMappingURL=AcEdDistanceHandler.d.ts.map