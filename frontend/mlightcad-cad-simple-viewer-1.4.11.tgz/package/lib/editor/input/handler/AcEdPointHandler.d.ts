import { AcGePoint3dLike } from '@mlightcad/data-model';
import { AcEdPromptPointOptions } from '../prompt/AcEdPromptPointOptions';
import { AcEdInputHandler } from './AcEdInputHandler';
/**
 * Handles validation and parsing of point user input.
 */
export declare class AcEdPointHandler implements AcEdInputHandler<AcGePoint3dLike> {
    protected options: AcEdPromptPointOptions;
    constructor(options: AcEdPromptPointOptions);
    parse(x: string, y?: string): {
        x: number;
        y: number;
        z: number;
    } | null;
}
//# sourceMappingURL=AcEdPointHandler.d.ts.map