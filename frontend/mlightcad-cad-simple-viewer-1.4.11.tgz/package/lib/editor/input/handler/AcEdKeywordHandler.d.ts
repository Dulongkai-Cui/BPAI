import { AcEdPromptKeywordOptions } from '../prompt/AcEdPromptKeywordOptions';
import { AcEdInputHandler } from './AcEdInputHandler';
/**
 * Validates keyword input according to {@link AcEdPromptKeywordOptions}.
 */
export declare class AcEdKeywordHandler implements AcEdInputHandler<string> {
    private options;
    constructor(options: AcEdPromptKeywordOptions);
    parse(value: string): string | null;
}
//# sourceMappingURL=AcEdKeywordHandler.d.ts.map