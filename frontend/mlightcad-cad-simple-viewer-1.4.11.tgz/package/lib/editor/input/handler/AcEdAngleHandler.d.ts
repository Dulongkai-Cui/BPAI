import { AcEdPromptAngleOptions } from '../prompt/AcEdPromptAngleOptions';
import { AcEdInputHandler } from './AcEdInputHandler';
/**
 * Validates angular numeric input.
 * Uses degrees. Fully compatible with PromptAngleOptions behavior in AutoCAD.
 */
export declare class AcEdAngleHandler implements AcEdInputHandler<number> {
    private options;
    constructor(options: AcEdPromptAngleOptions);
    parse(value: string): number | null;
}
//# sourceMappingURL=AcEdAngleHandler.d.ts.map