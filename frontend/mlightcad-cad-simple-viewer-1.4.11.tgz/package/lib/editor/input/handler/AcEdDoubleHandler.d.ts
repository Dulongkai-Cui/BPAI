import { AcEdNumericalHandler } from './AcEdNumericalHandler';
/**
 * Handles validation and parsing of double-precision floating-point input.
 */
export declare class AcEdDoubleHandler extends AcEdNumericalHandler {
}
//# sourceMappingURL=AcEdDoubleHandler.d.ts.map