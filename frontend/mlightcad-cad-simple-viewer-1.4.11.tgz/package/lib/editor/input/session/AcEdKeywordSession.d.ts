import { AcEdPromptKeywordOptions } from '../prompt/AcEdPromptKeywordOptions';
import { AcEdCommandLine } from '../ui/AcEdCommandLine';
import { AcEdInputSession } from './AcEdInputSession';
export declare class AcEdKeywordSession extends AcEdInputSession<string> {
    private cli;
    private options;
    private handler;
    constructor(cli: AcEdCommandLine, options: AcEdPromptKeywordOptions);
    protected onStart(): void;
    handleEnter(value: string): boolean;
    handleEscape(): void;
    protected cleanup(): void;
}
//# sourceMappingURL=AcEdKeywordSession.d.ts.map