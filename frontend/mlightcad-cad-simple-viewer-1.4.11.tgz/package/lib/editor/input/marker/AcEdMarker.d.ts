import { AcGePoint2dLike } from '@mlightcad/data-model';
/**
 * Supported marker shapes.
 */
export type AcEdMarkerType = 'circle' | 'triangle' | 'rect' | 'diamond' | 'x';
/**
 * Represents a single marker displayed in screen coordinates.
 *
 * A marker is a small shape (circle, triangle, or rectangle) rendered using DOM elements.
 * Its appearance is determined by type, size, and color.
 *
 * The marker:
 * - Is absolutely positioned on the screen.
 * - Cannot receive pointer events.
 * - Automatically injects required CSS once globally.
 */
export declare class AcEdMarker {
    /** DOM element representing the marker */
    private _el;
    /** Host element where the marker DOM is mounted */
    private _host;
    /** Size (width = height) of the marker in pixels */
    private _size;
    /** Marker shape type */
    private _type;
    /** Marker stroke or fill color */
    private _color;
    /**
     * Creates a new OSNAP marker instance.
     *
     * @param type - Shape type of the marker (`circle`, `triangle`, `rect`)
     * @param size - Size of the marker (width/height in px; triangle uses font-size)
     * @param color - Marker color (CSS color string)
     * @param host - Host container where marker DOM is mounted and positioned
     */
    constructor(type: AcEdMarkerType | undefined, size: number | undefined, color: string | undefined, host: HTMLElement);
    /**
     * Gets the current marker color.
     */
    get color(): string;
    /**
     * Sets marker color and updates DOM immediately.
     */
    set color(value: string);
    /**
     * Gets the current marker type.
     */
    get type(): AcEdMarkerType;
    /**
     * Sets the marker type and updates DOM shape instantly.
     */
    set type(value: AcEdMarkerType);
    /**
     * Injects required CSS into the document.
     * Ensures that CSS is only injected one time.
     */
    private static injectCSS;
    /**
     * Applies the appropriate CSS class and size properties
     * according to the marker's chosen shape type.
     */
    private applyShape;
    /**
     * Sets the screen position of the marker.
     *
     * @param pos - Position in screen coordinate in pixels
     */
    setPosition(pos: AcGePoint2dLike): void;
    /**
     * Removes the marker from DOM and cleans up resources.
     * Should be called when the marker is no longer needed.
     */
    destroy(): void;
}
//# sourceMappingURL=AcEdMarker.d.ts.map