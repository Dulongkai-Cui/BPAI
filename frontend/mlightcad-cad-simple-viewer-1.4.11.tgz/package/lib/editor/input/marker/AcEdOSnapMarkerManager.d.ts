import { AcGePoint2dLike } from '@mlightcad/data-model';
import { AcEdBaseView } from '../../view';
import { AcEdMarker, AcEdMarkerType } from './AcEdMarker';
/**
 * Manages a stack of markers using a singleton pattern.
 *
 * - `getInstance()` returns the global instance.
 * - `showMarker()` pushes a new marker onto the stack.
 * - `hideMarker()` pops the last marker.
 * - `clear()` removes all markers.
 *
 * Typical usage is to show temporary marker that appear and disappear
 * based on user cursor movement or snapping events.
 */
export declare class AcEdMarkerManager {
    /** The view associated with this input operation */
    private view;
    /** Internal stack of active markers */
    private stack;
    constructor(view: AcEdBaseView);
    /**
     * Creates and shows a new OSNAP marker at the specified position in world coordinate
     * system. The marker is added to the top of the internal stack.
     *
     * @param pos - Position in world coordinate system
     * @param type - Marker shape type
     * @param size - Marker size in pixels
     * @param color - Marker color (CSS string)
     */
    showMarker(pos: AcGePoint2dLike, type?: AcEdMarkerType, size?: number, color?: string): AcEdMarker;
    /**
     * Hides the most recently shown marker (LIFO).
     * If no marker exists, nothing happens.
     */
    hideMarker(): void;
    /**
     * Removes all active markers and clears the stack.
     * Should be called when OSNAP indicators need to be fully reset.
     */
    clear(): void;
    /**
     * Returns the marker at the top of the marker stack without removing it.
     *
     * This method is safe to call even when the stack is empty. In that case,
     * it returns `undefined`.
     *
     * @returns The top marker of the internal stack, or `undefined` if the
     * stack contains no marker.
     */
    top(): AcEdMarker | undefined;
}
//# sourceMappingURL=AcEdOSnapMarkerManager.d.ts.map