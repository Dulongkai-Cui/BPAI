import { AcEdPromptNumericalOptions } from './AcEdPromptNumericalOptions';
/**
 * Options for prompting the user to enter an integer (whole number),
 * similar to AutoCAD .NET `PromptIntegerOptions`.
 *
 * Inherits common numeric‑prompt behavior from `AcEdPromptNumericalOptions`,
 * and adds integer-specific configuration for minimum and maximum allowed values.
 */
export declare class AcEdPromptIntegerOptions extends AcEdPromptNumericalOptions {
    private _lowerLimit?;
    private _upperLimit?;
    /**
     * Constructs a new `AcEdPromptIntegerOptions`.
     *
     * AutoCAD .NET provides multiple overloads.
     * This constructor supports the same idea by allowing:
     * - just a message, or
     * - a message + lower limit, or
     * - a message + lower + upper limit.
     *
     * @param message - The message displayed to the user when prompting for an integer.
     * @param lowerLimit - (optional) Minimum allowed integer value. Enables `useLowerLimit`.
     * @param upperLimit - (optional) Maximum allowed integer value. Enables `useUpperLimit`.
     */
    constructor(message: string, lowerLimit?: number, upperLimit?: number);
    /**
     * Gets or sets the minimum allowed integer value.
     * Corresponds to `PromptIntegerOptions.LowerLimit` in AutoCAD .NET API.
     */
    get lowerLimit(): number | undefined;
    set lowerLimit(val: number | undefined);
    /**
     * Gets or sets the maximum allowed integer value.
     * Corresponds to `PromptIntegerOptions.UpperLimit` in AutoCAD .NET API.
     */
    get upperLimit(): number | undefined;
    set upperLimit(val: number | undefined);
}
//# sourceMappingURL=AcEdPromptIntegerOptions.d.ts.map