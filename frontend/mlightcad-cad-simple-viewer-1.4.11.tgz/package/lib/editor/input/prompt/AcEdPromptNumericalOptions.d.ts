import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Options for prompting the user to enter a numerical value (integer, double, etc.),
 * similar to AutoCAD .NET `PromptNumericalOptions`.
 *
 * Supports default value, allowing zero / negative, and whether Enter (no input) is accepted.
 */
export declare class AcEdPromptNumericalOptions extends AcEdPromptOptions<number> {
    private _defaultValue;
    private _useDefaultValue;
    private _allowNone;
    private _allowArbitraryInput;
    private _allowNegative;
    private _allowZero;
    /**
     * Constructs a new `AcEdPromptNumericalOptions` with a given prompt message.
     * @param message - The message shown to the user when prompting for a number.
     */
    constructor(message: string);
    /**
     * Gets or sets the default numerical value for the prompt.
     * This is used when the user presses ENTER without providing any other input.
     * In the .NET API, derived classes define the type-specific default value (e.g., integer, double).
     */
    get defaultValue(): number;
    set defaultValue(val: number);
    /**
     * Gets or sets whether the default value should be used when the user presses ENTER.
     * Corresponds to `PromptNumericalOptions.UseDefaultValue` in AutoCAD .NET API.
     */
    get useDefaultValue(): boolean;
    set useDefaultValue(flag: boolean);
    /**
     * Gets or sets whether pressing ENTER alone (no input) is accepted.
     * Corresponds to `PromptNumericalOptions.AllowNone` in AutoCAD .NET API.
     */
    get allowNone(): boolean;
    set allowNone(flag: boolean);
    /**
     * Gets or sets whether arbitrary (non-numeric) input is accepted.
     * If true, the prompt may allow strings or other input, depending on implementation.
     * Corresponds to `PromptNumericalOptions.AllowArbitraryInput` in AutoCAD .NET API.
     */
    get allowArbitraryInput(): boolean;
    set allowArbitraryInput(flag: boolean);
    /**
     * Gets or sets whether negative numeric values are allowed.
     * Corresponds to `PromptNumericalOptions.AllowNegative` in AutoCAD .NET API.
     */
    get allowNegative(): boolean;
    set allowNegative(flag: boolean);
    /**
     * Gets or sets whether zero is an acceptable numeric value.
     * Corresponds to `PromptNumericalOptions.AllowZero` in AutoCAD .NET API.
     */
    get allowZero(): boolean;
    set allowZero(flag: boolean);
}
//# sourceMappingURL=AcEdPromptNumericalOptions.d.ts.map