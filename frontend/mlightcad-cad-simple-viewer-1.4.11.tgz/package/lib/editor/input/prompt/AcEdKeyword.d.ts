/**
 * Represents a single keyword option in a prompt, similar to Autodesk.AutoCAD.EditorInput.Keyword.
 * Keywords can be shown to the user, used internally as global identifiers, and can be enabled/disabled or visible/hidden.
 */
export declare class AcEdKeyword {
    private _displayName;
    private _enabled;
    private _globalName;
    private _isReadOnly;
    private _localName;
    private _visible;
    /**
     * Creates a new Keyword.
     * @param displayName - The text displayed to the user for this keyword.
     * @param globalName - The internal global name (never shown to user). Defaults to `displayName`.
     * @param localName - Internal local name (usually same as global name). Defaults to `globalName`.
     * @param enabled - Whether the keyword is currently enabled. Default is `true`.
     * @param isReadOnly - If `true`, the keyword properties cannot be modified. Default is `false`.
     * @param visible - Whether the keyword is visible to the user. Default is `true`.
     */
    constructor(displayName: string, globalName?: string, localName?: string, enabled?: boolean, isReadOnly?: boolean, visible?: boolean);
    /**
     * Gets or sets the display name of the keyword.
     * This is the name shown to the user in prompts.
     * Setting has no effect if `isReadOnly` is true.
     */
    get displayName(): string;
    set displayName(name: string);
    /**
     * Gets or sets whether the keyword is currently enabled.
     * Disabled keywords cannot be selected by the user.
     * Setting has no effect if `isReadOnly` is true.
     */
    get enabled(): boolean;
    set enabled(flag: boolean);
    /**
     * Gets or sets the global name of the keyword.
     * The global name is used internally by programs and is never displayed to the user.
     * Setting has no effect if `isReadOnly` is true.
     */
    get globalName(): string;
    set globalName(name: string);
    /**
     * Gets a value indicating whether the keyword is read-only.
     * True if the keyword is read-only; otherwise, false.
     */
    get isReadOnly(): boolean;
    /**
     * Gets or sets the local name of the keyword.
     * Usually the same as the global name; not displayed to the user.
     * Setting has no effect if `isReadOnly` is true.
     */
    get localName(): string;
    set localName(name: string);
    /**
     * Gets or sets whether the keyword is visible to the user.
     * Hidden keywords cannot be selected by typing, but can be used programmatically.
     * Setting has no effect if `isReadOnly` is true.
     */
    get visible(): boolean;
    set visible(flag: boolean);
    /**
     * As AutoCAD .NET API, you cannot specify a keyword alias the same way as ObjectARX (Yes _Y).
     * There is no alias parameter in {@link AdKeywordCollection.add}.
     *
     * However, a different and implicit alias mechanism is provided as AutoCAD .NET API. The rule
     * is the capital letters in the keyword global name define the alias.
     *
     * User can type:
     * - Y → Yes
     * - N → No
     * - C → Cancel
     *
     * Multi-letter aliases
     * You can control the alias length by capitalizing multiple letters:
     *
     * ```typescript
     * opts.keywords.add("WireFrame");   // alias = WF
     * opts.keywords.add("HiddenLine");  // alias = HL
     * opts.keywords.add("Realistic");   // alias = R
     * ```
     *
     * User input:
     * - WF
     * - HL
     * - R
     */
    get alias(): string;
}
//# sourceMappingURL=AcEdKeyword.d.ts.map