import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Options for prompting the user to enter a keyword,
 * similar to AutoCAD .NET `PromptKeywordOptions`.
 */
export declare class AcEdPromptKeywordOptions extends AcEdPromptOptions<string> {
    private _allowNone;
    private _allowArbitraryInput;
    /**
     * Constructs a new `AcEdPromptKeywordOptions` with a given prompt message.
     * @param message - The message shown to the user when prompting for a number.
     */
    constructor(message: string);
    /**
     * Gets or sets whether pressing ENTER alone (no input) is accepted.
     * Corresponds to `PromptKeywordOptions.AllowNone` in AutoCAD .NET API.
     */
    get allowNone(): boolean;
    set allowNone(flag: boolean);
    /**
     * Gets or sets whether arbitrary input is accepted.
     * If true, the prompt may allow strings or other input, depending on implementation.
     * Corresponds to `PromptKeywordOptions.AllowArbitraryInput` in AutoCAD .NET API.
     */
    get allowArbitraryInput(): boolean;
    set allowArbitraryInput(flag: boolean);
}
//# sourceMappingURL=AcEdPromptKeywordOptions.d.ts.map