import { AcEdKeyword } from './AcEdKeyword';
/**
 * A collection of `AcEdKeyword` objects, mirroring `Autodesk.AutoCAD.EditorInput.KeywordCollection`.
 * Represents the set of valid keywords for a prompt.
 */
export declare class AcEdKeywordCollection {
    private _keywords;
    private _defaultKeyword?;
    /**
     * Constructs a keyword collection by parsing an ObjectARX-style keyword list
     * string, equivalent to the `kwl` argument of `acedInitGet`.
     *
     * The keyword list is a single space-delimited string. Each token defines one
     * keyword specification and is interpreted using AutoCAD command-line rules:
     *
     * ### Basic keywords
     * - Keywords are separated by one or more spaces.
     * - Each keyword may contain only letters, digits, and hyphens (`-`).
     *
     * ```ts
     * new AcEdKeywordCollection("Width Height Depth")
     * ```
     *
     * ### Abbreviation rules
     * AutoCAD recognizes keyword abbreviations using one of two methods:
     *
     * 1. **Capital-letter method**
     *    Uppercase letters inside the keyword define the required abbreviation.
     *
     *    ```text
     *    LType   → LT
     *    eXit    → X
     *    ```
     *
     * 2. **Comma method**
     *    The full keyword is written in uppercase, followed by a comma and an
     *    explicit abbreviation.
     *
     *    ```text
     *    LTYPE,LT
     *    ```
     *
     *    The abbreviation part after the comma is *not* part of the returned
     *    keyword value.
     *
     * ### Local and global keywords
     * The keyword list may define local-to-global mappings using an underscore (`_`):
     *
     * ```text
     * Ja Nein _ Yes No
     * ```
     *
     * - Keywords before `_` are **local**
     * - Keywords after `_` are **global**
     * - When a local keyword is entered, the corresponding global keyword is returned
     * - Global keywords may be entered explicitly using a leading underscore
     *
     * A one-to-one match is not required:
     * - Extra local keywords return an empty string
     * - Extra global keywords are valid but require a leading underscore
     *
     * ### Returned values
     * Regardless of how the user types a keyword (full form or abbreviation),
     * the resolved keyword value is always the **global keyword as specified in
     * the keyword list**, preserving its original capitalization.
     *
     * @param kwl Optional ObjectARX-style keyword list string. If omitted, an
     *            empty keyword collection is created.
     */
    constructor(kwl?: string);
    /**
     * Adds a new keyword (displayName only).
     * @param displayName - The text shown to the user for this keyword.
     * @returns The newly created `AcEdKeyword`.
     */
    add(displayName: string): AcEdKeyword;
    /**
     * Adds a new keyword with globalName and localName.
     * @param globalName - The internal, non-display name.
     * @param localName - The name that the user types to select the keyword.
     * @returns The newly created `AcEdKeyword`.
     */
    add(globalName: string, localName: string): AcEdKeyword;
    /**
     * Adds a new keyword with displayName, globalName, localName, enabled, visible.
     * @param displayName - The text shown to the user.
     * @param globalName - Internal identifier for the keyword.
     * @param localName - The name used by the user to type the keyword.
     * @param enabled - If false, the keyword cannot be selected.
     * @param visible - If false, the keyword is hidden from display.
     * @returns The newly created `AcEdKeyword`.
     */
    add(displayName: string, globalName: string, localName: string, enabled?: boolean, visible?: boolean): AcEdKeyword;
    /** Removes all keywords from the collection. */
    clear(): void;
    /** Copies the keywords of this collection into a plain array. */
    toArray(): AcEdKeyword[];
    /** Gets or sets the default keyword for this collection. */
    get default(): AcEdKeyword | undefined;
    set default(kw: AcEdKeyword | undefined);
    /** Returns a string representing the visible, enabled keywords for display. */
    getDisplayString(showNoDefault?: boolean): string;
    /** Returns an iterator over the `AcEdKeyword` objects in this collection. */
    [Symbol.iterator](): Iterator<AcEdKeyword>;
    /** Finds a keyword by its display name (case-insensitive). */
    findByDisplayName(displayName: string): AcEdKeyword | undefined;
    /** Finds a keyword by its global name (case-insensitive). */
    findByGlobalName(globalName: string): AcEdKeyword | undefined;
    /** Finds a keyword by its global name (case-insensitive), alias, or display name */
    findByName(name: string): AcEdKeyword | undefined;
    /** Gets the number of keywords in this collection. */
    get count(): number;
}
//# sourceMappingURL=AcEdKeywordCollection.d.ts.map