import { AcGePoint3d } from '@mlightcad/data-model';
import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Represents options for prompting the user to select a point, similar to
 * AutoCAD .NET `PromptPointOptions` and `PromptCornerOptions`.
 *
 * Supports specifying a base point, keywords, and how the message is displayed.
 */
export declare class AcEdPromptPointOptions extends AcEdPromptOptions<AcGePoint3d> {
    private _basePoint?;
    private _useBasePoint;
    private _useDashedLine;
    private _allowNone;
    /**
     * Constructs a new `AcEdPromptPointOptions` with a given prompt message.
     * @param message - The message to show to the user in the prompt.
     */
    constructor(message: string);
    /**
     * Gets or sets the base point used for relative selection.
     * In AutoCAD .NET, this is `PromptPointOptions.BasePoint`.
     * When `useBasePoint` is true, a rubber-band line will be drawn from the base point to the cursor.
     */
    get basePoint(): AcGePoint3d | undefined;
    set basePoint(point: AcGePoint3d | undefined);
    /**
     * Gets or sets whether the base point should be used when prompting the next point.
     * In AutoCAD .NET, this is `PromptPointOptions.UseBasePoint`.
     * If true, the prompt will display a visual line from the base point to the cursor.
     */
    get useBasePoint(): boolean;
    set useBasePoint(flag: boolean);
    /**
     * Gets or sets whether a dashed line should indicate the base point.
     * Corresponds to `PromptPointOptions.UseDashedLine`.
     */
    get useDashedLine(): boolean;
    set useDashedLine(flag: boolean);
    /**
     * Gets or sets whether the user is allowed to press Enter to specify no point.
     * Corresponds to `PromptPointOptions.AllowNone` in AutoCAD .NET.
     */
    get allowNone(): boolean;
    set allowNone(flag: boolean);
}
//# sourceMappingURL=AcEdPromptPointOptions.d.ts.map