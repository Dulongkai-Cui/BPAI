import { AcGePoint3d } from '@mlightcad/data-model';
import { AcEdPreviewJig } from '../AcEdPreviewJig';
import { AcEdKeywordCollection } from './AcEdKeywordCollection';
/**
 * Represents the base class for prompt options in the Editor, similar to `Autodesk.AutoCAD.EditorInput.PromptOptions`.
 * Provides configuration for the prompt message, keyword collection, and how keywords are appended/displayed.
 */
export declare class AcEdPromptOptions<T = number | string | AcGePoint3d> {
    private _jig?;
    private _message;
    private _appendKeywordsToMessage;
    private _isReadOnly;
    private _keywords;
    /**
     * Constructs a new `AcEdPromptOptions` with a given prompt message.
     * @param message - The message to show to the user in the prompt.
     */
    constructor(message: string);
    /**
     * Gets or sets the preview jig in the prompt.
     */
    get jig(): AcEdPreviewJig<T> | undefined;
    set jig(jig: AcEdPreviewJig<T> | undefined);
    /**
     * Gets or sets the message displayed in the prompt.
     * Corresponds to `PromptOptions.Message` in AutoCAD .NET API.
     */
    get message(): string;
    set message(msg: string);
    /**
     * Gets or sets whether keywords should be appended automatically to the message when rendering.
     * In AutoCAD .NET, this is `PromptOptions.AppendKeywordsToMessage`.
     */
    get appendKeywordsToMessage(): boolean;
    set appendKeywordsToMessage(value: boolean);
    /**
     * Gets whether this `AcEdPromptOptions` is read-only.
     * When read-only, properties such as `message` and `appendKeywordsToMessage` cannot be changed.
     * Corresponds to `PromptOptions.IsReadOnly`.
     */
    get isReadOnly(): boolean;
    /**
     * Gets the collection of keywords for this prompt.
     * Mirrors `PromptOptions.Keywords` in AutoCAD .NET API.
     */
    get keywords(): AcEdKeywordCollection;
    /**
     * Sets both the prompt message and the display keywords from a single combined string.
     * This corresponds to `PromptOptions.SetMessageAndKeywords(string messageAndKeywords, string globalKeywords)` in the .NET API.
     *
     * The `messageAndKeywords` string is typically of the form `"Message text [Keyword1/Keyword2/...]"`.
     * The `globalKeywords` parameter is a space-separated list of global keyword names.
     *
     * After calling this, the `message` is updated to the part before the `[ ... ]`, and the `keywords` collection
     * is updated to contain the specified global keywords.
     *
     * @param messageAndKeywords - The combined message and keywords for the prompt.
     * @param globalKeywords - A space-separated string listing the global names of the keywords.
     */
    setMessageAndKeywords(messageAndKeywords: string, globalKeywords: string): this;
}
//# sourceMappingURL=AcEdPromptOptions.d.ts.map