import { AcGeBox2d } from '@mlightcad/data-model';
import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Represents prompt options for selecting a rectangular box (two corners).
 */
export declare class AcEdPromptBoxOptions extends AcEdPromptOptions<AcGeBox2d> {
    private _secondCornerMessage;
    private _useBasePoint;
    private _useDashedLine;
    constructor(firstCornerMessage: string, secondCornerMessage: string);
    get firstCornerMessage(): string;
    set firstCornerMessage(value: string);
    get secondCornerMessage(): string;
    set secondCornerMessage(value: string);
    get useBasePoint(): boolean;
    set useBasePoint(flag: boolean);
    get useDashedLine(): boolean;
    set useDashedLine(flag: boolean);
}
//# sourceMappingURL=AcEdPromptBoxOptions.d.ts.map