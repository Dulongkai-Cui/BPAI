import { AcGePoint3d } from '@mlightcad/data-model';
import { AcEdPromptNumericalOptions } from './AcEdPromptNumericalOptions';
/**
 * Options for prompting the user to input a distance, similar to
 * AutoCAD .NET `PromptDistanceOptions`.
 *
 * Supports a base point, default distance, 2D projection, dashed-line preview, and keywords.
 */
export declare class AcEdPromptDistanceOptions extends AcEdPromptNumericalOptions {
    private _basePoint?;
    private _useBasePoint;
    private _useDashedLine;
    private _only2d;
    /**
     * Constructs a new `AcEdPromptDistanceOptions` with a prompt message.
     * @param message - The message shown to the user in the prompt.
     */
    constructor(message: string);
    /**
     * Gets or sets the base point for the distance prompt.
     * Corresponds to `PromptDistanceOptions.BasePoint`.
     */
    get basePoint(): AcGePoint3d | undefined;
    set basePoint(point: AcGePoint3d | undefined);
    /**
     * Gets or sets whether the base point should be used for the prompt.
     * When true, a rubber-band line from the base point to the cursor may be shown.
     * Corresponds to `PromptDistanceOptions.UseBasePoint`.
     */
    get useBasePoint(): boolean;
    set useBasePoint(flag: boolean);
    /**
     * Gets or sets whether a dashed-line (“rubber band”) is drawn from the base point to the cursor.
     * Corresponds to `PromptDistanceOptions.UseDashedLine`.
     */
    get useDashedLine(): boolean;
    set useDashedLine(flag: boolean);
    /**
     * Gets or sets whether the distance should be measured in 2D (projected into the current UCS).
     * If true, the returned distance is the 2D projection from the base point.
     * Corresponds to `PromptDistanceOptions.Only2d`.
     */
    get only2d(): boolean;
    set only2d(flag: boolean);
}
//# sourceMappingURL=AcEdPromptDistanceOptions.d.ts.map