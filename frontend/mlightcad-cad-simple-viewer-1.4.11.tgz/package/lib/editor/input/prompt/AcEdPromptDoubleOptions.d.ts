import { AcEdPromptNumericalOptions } from './AcEdPromptNumericalOptions';
/**
 * Options for prompting the user to enter a double-precision (floating point) number,
 * similar to AutoCAD .NET `PromptDoubleOptions`.
 *
 * Inherits common numeric-prompt behavior from `AcEdPromptNumericalOptions`.
 */
export declare class AcEdPromptDoubleOptions extends AcEdPromptNumericalOptions {
}
//# sourceMappingURL=AcEdPromptDoubleOptions.d.ts.map