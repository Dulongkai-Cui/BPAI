import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Represents prompt options for selecting a single entity.
 * Mirrors `Autodesk.AutoCAD.EditorInput.PromptEntityOptions`.
 */
export declare class AcEdPromptEntityOptions extends AcEdPromptOptions<string> {
    /** Whether ENTER (no selection) is allowed */
    private _allowNone;
    /** Whether entities on locked layers are selectable */
    private _allowObjectOnLockedLayer;
    /** Message displayed when selection is rejected */
    private _rejectMessage;
    /**
     * Allowed entity class names.
     * Empty set means "allow all".
     */
    private _allowedClasses;
    constructor(message: string);
    /**
     * Gets or sets whether the user may press ENTER without selecting an entity.
     * Corresponds to `PromptEntityOptions.AllowNone`.
     */
    get allowNone(): boolean;
    set allowNone(value: boolean);
    /**
     * Gets or sets whether entities on locked layers can be selected.
     * Corresponds to `PromptEntityOptions.AllowObjectOnLockedLayer`.
     */
    get allowObjectOnLockedLayer(): boolean;
    set allowObjectOnLockedLayer(value: boolean);
    /**
     * Gets the rejection message shown when the selected entity is invalid.
     * Corresponds to `PromptEntityOptions.RejectMessage`.
     */
    get rejectMessage(): string;
    /**
     * Sets the rejection message.
     * Corresponds to `PromptEntityOptions.SetRejectMessage()`.
     */
    setRejectMessage(message: string): this;
    /**
     * Adds an allowed entity class name.
     * Corresponds to `PromptEntityOptions.AddAllowedClass()`.
     *
     * @param className - Entity class name (e.g. "Line", "Circle")
     */
    addAllowedClass(className: string): this;
    /**
     * Removes an allowed entity class name.
     * Corresponds to `PromptEntityOptions.RemoveAllowedClass()`.
     */
    removeAllowedClass(className: string): this;
    /**
     * Clears all allowed class restrictions (allow all entities).
     */
    clearAllowedClasses(): this;
    /**
     * Checks whether a given entity class is allowed.
     * Used internally by selection logic.
     */
    isClassAllowed(className: string): boolean;
}
//# sourceMappingURL=AcEdPromptEntityOptions.d.ts.map