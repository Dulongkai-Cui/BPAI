import { AcGePoint3d } from '@mlightcad/data-model';
import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Options for prompting the user to enter an angle, similar to
 * AutoCAD .NET `PromptAngleOptions`.
 *
 * Supports a base point, default angle, keywords, and various validation flags.
 */
export declare class AcEdPromptAngleOptions extends AcEdPromptOptions<number> {
    private _basePoint?;
    private _useBasePoint;
    private _useDashedLine;
    private _useAngleBase;
    private _defaultValue;
    private _useDefaultValue;
    private _allowZero;
    private _allowNegative;
    /**
     * Constructs a new `AcEdPromptAngleOptions` with a given prompt message.
     * @param message - The prompt message shown to the user.
     */
    constructor(message: string);
    /**
     * Gets or sets the base point for the angle prompt.
     * Corresponds to `PromptAngleOptions.BasePoint`.
     */
    get basePoint(): AcGePoint3d | undefined;
    set basePoint(point: AcGePoint3d | undefined);
    /**
     * Gets or sets whether to use the base point for the prompt.
     * When true, the prompt may render a dashed line from the base point to the cursor.
     * Corresponds to `PromptAngleOptions.UseBasePoint`.
     */
    get useBasePoint(): boolean;
    set useBasePoint(flag: boolean);
    /**
     * Gets or sets whether a dashed line should indicate the base point.
     * Corresponds to `PromptAngleOptions.UseDashedLine`.
     */
    get useDashedLine(): boolean;
    set useDashedLine(flag: boolean);
    /**
     * Gets or sets whether the base "angle base" should be used.
     * Corresponds to `PromptAngleOptions.UseAngleBase`.
     */
    get useAngleBase(): boolean;
    set useAngleBase(flag: boolean);
    /**
     * Gets or sets the default angle value (in degrees or radians, depending on your implementation).
     * This is used when the user presses ENTER, if `useDefaultValue` is true.
     * Corresponds to `PromptAngleOptions.DefaultValue`.
     */
    get defaultValue(): number;
    set defaultValue(val: number);
    /**
     * Gets or sets whether the default value is used when the user presses ENTER.
     * Corresponds to `PromptAngleOptions.UseDefaultValue`.
     */
    get useDefaultValue(): boolean;
    set useDefaultValue(flag: boolean);
    /**
     * Gets or sets whether zero-valued angles are accepted.
     * Corresponds to `PromptAngleOptions.AllowZero`.
     */
    get allowZero(): boolean;
    set allowZero(flag: boolean);
    /**
     * Gets or sets whether negative-valued angles are accepted.
     * While not always documented directly on `PromptAngleOptions`, numerical prompts in AutoCAD
     * often support negative input via a similar property. (Analogous to PromptNumericalOptions)
     */
    get allowNegative(): boolean;
    set allowNegative(flag: boolean);
}
//# sourceMappingURL=AcEdPromptAngleOptions.d.ts.map