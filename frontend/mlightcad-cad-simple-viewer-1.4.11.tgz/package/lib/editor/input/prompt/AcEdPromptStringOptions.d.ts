import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Options for prompting the user to enter a string, similar to
 * AutoCAD .NET `PromptStringOptions`.
 *
 * Allows configuration of whether spaces are permitted, default values,
 * and whether the default should be used when the user presses ENTER.
 */
export declare class AcEdPromptStringOptions extends AcEdPromptOptions<string> {
    private _allowSpaces;
    private _allowEmpty;
    private _maxLength?;
    private _defaultValue;
    private _useDefaultValue;
    /**
     * Constructs a new `AcEdPromptStringOptions` with a given prompt message.
     * @param message - The message shown to the user when prompting for a string.
     */
    constructor(message: string);
    /**
     * Gets or sets whether spaces are allowed in the input string.
     * If `false`, pressing the spacebar may terminate the input (depending on implementation).
     * Corresponds to `PromptStringOptions.AllowSpaces` in AutoCAD .NET.
     */
    get allowSpaces(): boolean;
    set allowSpaces(flag: boolean);
    /**
     * When true, an empty string is considered valid input.
     * Default: `false` — empty string is not allowed.
     */
    get allowEmpty(): boolean;
    set allowEmpty(flag: boolean);
    /**
     * Maximum allowed number of characters in the input string.
     * If `undefined`, there is no length restriction.
     */
    get maxLength(): number | undefined;
    set maxLength(value: number | undefined);
    /**
     * Gets or sets the default string value.
     * This value may be used if the user presses ENTER, depending on `useDefaultValue`.
     * Corresponds to `PromptStringOptions.DefaultValue` in AutoCAD .NET.
     */
    get defaultValue(): string;
    set defaultValue(val: string);
    /**
     * Gets or sets whether the default value should be used when the user presses ENTER
     * without entering any other input.
     * Corresponds to `PromptStringOptions.UseDefaultValue` in AutoCAD .NET.
     */
    get useDefaultValue(): boolean;
    set useDefaultValue(flag: boolean);
}
//# sourceMappingURL=AcEdPromptStringOptions.d.ts.map