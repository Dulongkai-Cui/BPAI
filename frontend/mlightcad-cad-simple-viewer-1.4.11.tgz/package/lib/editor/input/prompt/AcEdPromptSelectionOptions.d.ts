import { AcEdPromptOptions } from './AcEdPromptOptions';
/**
 * Represents prompt options for one selection set
 * Mirrors `Autodesk.AutoCAD.EditorInput.PromptSelectionOptions`.
 */
export declare class AcEdPromptSelectionOptions extends AcEdPromptOptions<string> {
    /** Whether to force single object selection only */
    private _singleOnly;
    constructor(message: string);
    /**
     * Gets or sets whether to force single object selection only
     */
    get singleOnly(): boolean;
    set singleOnly(value: boolean);
}
//# sourceMappingURL=AcEdPromptSelectionOptions.d.ts.map