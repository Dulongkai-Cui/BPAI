import { AcCmEventManager } from '@mlightcad/data-model';
import { AcEdCommand } from '../command';
import { AcEdBaseView } from '../view/AcEdBaseView';
import { AcEdCorsorType } from './AcEdCursorManager';
import { AcEdPromptAngleOptions, AcEdPromptBoxOptions, AcEdPromptDistanceOptions, AcEdPromptEntityOptions, AcEdPromptKeywordOptions, AcEdPromptPointOptions, AcEdPromptSelectionOptions, AcEdPromptStringOptions } from './prompt';
/**
 * Event arguments for system variable related events.
 */
export interface AcDbSysVarEventArgs {
    /** The system variable name */
    name: string;
}
/**
 * Event arguments for command lifecycle events.
 *
 * Contains the command instance that triggered the event.
 */
export interface AcEdCommandEventArgs {
    /** The command instance involved in the event */
    command: AcEdCommand;
}
/**
 * Advanced input handler for CAD operations providing high-level user interaction methods.
 *
 * This class serves as a wrapper for all types of user input including:
 * - Point input (mouse clicks, coordinates)
 * - Entity selection (single or multiple entities)
 * - String, number, angle, and distance input
 * - Cursor management and visual feedback
 *
 * The editor abstracts away low-level mouse and keyboard events, providing a clean API
 * for command implementations. Instead of listening to raw DOM events, commands should
 * use the methods provided by this class.
 *
 * @example
 * ```typescript
 * // Get user input for a point
 * const point = await editor.getPoint();
 * console.log('User clicked at:', point);
 *
 * // Get entity selection
 * const selection = await editor.getSelection();
 * console.log('Selected entities:', selection.ids);
 *
 * // Change cursor appearance
 * editor.setCursor(AcEdCorsorType.Crosshair);
 * ```
 */
export declare class AcEditor {
    /** Previously set cursor type for restoration */
    private _previousCursor?;
    /** Currently active cursor type */
    private _currentCursor?;
    /** Manager for cursor appearance and behavior */
    private _cursorManager;
    /** Manager for mouse and keyboard input */
    private _inputManager;
    /** The view this editor is associated with */
    protected _view: AcEdBaseView;
    /**
     * Editor events
     */
    readonly events: {
        /**
         * Fired after a system variable is changed directly through the SETVAR command or
         * by entering the variable name at the command line.
         */
        sysVarChanged: AcCmEventManager<AcDbSysVarEventArgs>;
        /** Fired just before the command starts executing */
        commandWillStart: AcCmEventManager<AcEdCommandEventArgs>;
        /** Fired after the command finishes executing */
        commandEnded: AcCmEventManager<AcEdCommandEventArgs>;
    };
    /**
     * Creates a new editor instance for the specified view.
     *
     * @param view - The view that this editor will handle input for
     */
    constructor(view: AcEdBaseView);
    /**
     * The flag to indicate whether it is currently in an “input acquisition” mode (e.g., point
     * selection, distance/angle prompt, string prompt, etc.),
     */
    get isActive(): boolean;
    /**
     * Queues scripted command-line inputs for subsequent getXXX prompts.
     * One entry equals one Enter-confirmed input.
     */
    enqueueScriptInputs(inputs: string[]): void;
    /** Clears any queued scripted inputs. */
    clearScriptInputs(): void;
    /**
     * Gets the currently active cursor type.
     *
     * @returns The current cursor type, or undefined if none is set
     */
    get currentCursor(): AcEdCorsorType | undefined;
    /**
     * Restores the previously set cursor.
     *
     * This is useful for temporarily changing the cursor and then reverting
     * to the previous state.
     */
    restoreCursor(): void;
    /**
     * Sets the cursor appearance for the view.
     *
     * The previous cursor type is stored for potential restoration.
     *
     * @param cursorType - The cursor type to set
     *
     * @example
     * ```typescript
     * editor.setCursor(AcEdCorsorType.Crosshair);  // For precise point input
     * editor.setCursor(AcEdCorsorType.Grab);       // For pan operations
     * ```
     */
    setCursor(cursorType: AcEdCorsorType): void;
    /**
     * Prompts the user to input a point by clicking on the view or inputting
     * one coordinate value.
     *
     * This method returns a promise that resolves after the user clicks
     * on the view or inputs one valid coordinate value, providing the
     * world coordinates of the click point.
     *
     * @returns Promise that resolves to the input point coordinates
     */
    getPoint(options: AcEdPromptPointOptions): Promise<import("@mlightcad/data-model").AcGeVector3dLike>;
    /**
     * Prompts the user to input an angle by clicking on the view or input
     * one number.
     *
     * This method returns a promise that resolves after the user clicks
     * on the view or inputs one valid angle value.
     *
     * @returns Promise that resolves to the input angle value.
     */
    getAngle(options: AcEdPromptAngleOptions): Promise<number>;
    /**
     * Prompts the user to input a distance by clicking on the view or input
     * one number.
     *
     * This method returns a promise that resolves after the user clicks
     * on the view or inputs one valid distance value.
     *
     * @returns Promise that resolves to the input distance value.
     */
    getDistance(options: AcEdPromptDistanceOptions): Promise<number>;
    /**
     * Prompts the user to input a string.
     *
     * @returns Promise that resolves to the input one string.
     */
    getString(options: AcEdPromptStringOptions): Promise<string>;
    /**
     * Prompts the user to input a keyword.
     *
     * @returns Promise that resolves to the input one keyword.
     */
    getKeywords(options: AcEdPromptKeywordOptions): Promise<string>;
    /**
     * Prompts the user to input a keyword.
     *
     * @returns Promise that resolves to the input one keyword.
     */
    getEntity(options: AcEdPromptEntityOptions): Promise<string | null>;
    /**
     * Prompts the user to select entities using box selection.
     *
     * This method allows the user to drag a selection box to select
     * multiple entities at once. The selection behavior follows CAD
     * conventions (left-to-right for crossing, right-to-left for window).
     *
     * @returns Promise that resolves to the selection set containing selected entity IDs
     */
    getSelection(options: AcEdPromptSelectionOptions): Promise<string[]>;
    /**
     * Prompts the user to specify a rectangular bounding box (two corners).
     *
     * @returns Promise that resolves to rectangular bounding box.
     */
    getBox(options: AcEdPromptBoxOptions): Promise<import("@mlightcad/data-model").AcGeBox2d>;
}
//# sourceMappingURL=AcEditor.d.ts.map