import { AcGePoint2dLike } from '@mlightcad/data-model';
import { AcEdBaseView } from '../../view';
/**
 * AcEdFloatingMessage
 * -----------------------------------------------------------------------------
 * A lightweight floating UI component that displays a short text message
 * near the mouse cursor, similar to AutoCAD's dynamic prompt / tooltip.
 *
 * Responsibilities:
 * - Create and manage a floating DOM element with a text label
 * - Follow mouse movement while visible
 * - Automatically show / hide on mouse enter / leave
 * - Ensure the floating message stays inside parent bounds
 * - Manage its own DOM lifecycle and event listeners
 *
 * Non-Responsibilities (by design):
 * - No input boxes
 * - No keyboard handling
 * - No OSNAP logic
 * - No rubber-band / preview drawing
 * - No CAD command logic
 *
 * This class serves as a reusable base for more advanced floating UI
 * components such as `AcEdFloatingInput`, which extend this class
 * to add inputs, validation, OSNAP, and commit workflows.
 */
export declare class AcEdFloatingMessage {
    /** The view associated with the current editor context */
    protected view: AcEdBaseView;
    /**
     * Parent element used for positioning and mouse tracking.
     * Typically the canvas container or viewport element.
     */
    protected parent: HTMLElement;
    /**
     * Host element where floating DOM is mounted.
     * This should be tied to the view area (not global document body).
     */
    protected host: HTMLElement;
    /**
     * Root container of the floating message.
     * Positioned absolutely and follows the mouse cursor.
     */
    protected container: HTMLDivElement;
    /**
     * Text label element used to display the floating message.
     */
    protected label: HTMLSpanElement;
    /** Whether the floating message is currently visible */
    protected visible: boolean;
    /** Whether this instance has been permanently disposed */
    protected disposed: boolean;
    /** Ensures CSS is injected only once globally */
    private static stylesInjected;
    /** Cached event handler: mouse enter */
    protected boundOnMouseEnter: (e: MouseEvent) => void;
    /** Cached event handler: mouse leave */
    protected boundOnMouseLeave: (e: MouseEvent) => void;
    /** Cached event handler: mouse move */
    protected boundOnMouseMove: (e: MouseEvent) => void;
    /**
     * Constructs a floating message widget.
     *
     * @param view   The active editor view
     * @param options.parent  Parent element used for positioning
     * @param options.message Initial message text
     */
    constructor(view: AcEdBaseView, options: {
        parent?: HTMLElement;
        message?: string;
    });
    /**
     * Injects minimal CSS required for the floating message.
     * This is done once globally to avoid duplicate styles.
     */
    protected injectCSS(): void;
    /**
     * Indicates whether the floating message is currently visible.
     */
    get isVisible(): boolean;
    /**
     * Shows the floating message at the given mouse position
     * and starts tracking mouse movement.
     *
     * @param pos Mouse position in browser coordinates
     */
    showAt(pos: AcGePoint2dLike): void;
    /**
     * Hides the floating message and stops mouse tracking.
     * Safe to call multiple times.
     */
    hide(): void;
    /**
     * Permanently disposes this floating message.
     *
     * - Removes all event listeners
     * - Removes DOM elements
     * - After disposal, the instance must not be reused
     */
    dispose(): void;
    /**
     * Updates the position of the floating message to follow the mouse
     * while ensuring it stays within the parent bounds.
     *
     * @param pos Mouse position in browser coordinates
     */
    protected setPosition(pos: AcGePoint2dLike): import("@mlightcad/data-model").AcGePoint2d;
    /**
     * Mouse enter handler.
     * Shows the floating message at the current cursor position.
     */
    protected handleMouseEnter(e: MouseEvent): void;
    /**
     * Mouse leave handler.
     * Hides the floating message.
     */
    protected handleMouseLeave(): void;
    /**
     * Mouse move handler.
     * Updates floating message position.
     * Can be overridden by subclasses to extend behavior.
     */
    protected handleMouseMove(e: MouseEvent): void;
}
//# sourceMappingURL=AcEdFloatingMessage.d.ts.map