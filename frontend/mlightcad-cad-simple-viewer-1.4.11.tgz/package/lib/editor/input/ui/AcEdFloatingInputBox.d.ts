/**
 * Represents ONE floating input box (<input> element).
 * Tracks whether the user has typed anything manually.
 */
export declare class AcEdFloatingInputBox {
    /** The container element of this input */
    private parent;
    /** The actual text input element */
    private input;
    /** Whether the user typed something in this box */
    userTyped: boolean;
    /** Bound input handler for unbinding */
    private boundOnInput;
    /**
     * Constructs one instance of this UI component.
     * @param parent - The container element of this input
     */
    constructor(parent: HTMLElement);
    /** Mark input as invalid */
    markInvalid(): void;
    /** Mark input as valid */
    markValid(): void;
    /** Clear validation state */
    resetValidation(): void;
    /** Get placeholder */
    get placeholder(): string;
    /** Set placeholder */
    set placeholder(text: string);
    /** Set value */
    set value(v: string);
    /** Read current text */
    get value(): string;
    /** Return one flag to indicate whether the input box is focused. */
    get focused(): boolean;
    /** Forwards focus() to the underlying element. */
    focus(): void;
    /** Forwards select() to the underlying element. */
    select(): void;
    /** Forwards remove() to the underlying element. */
    remove(): void;
    /** Return true if the specified event is originated from this input box. */
    isEventTarget(e: KeyboardEvent): boolean;
    /** Dispose the input box by unbinding events */
    dispose(): void;
    /**
     * Add an event listener to the input element
     * @param type Event type (e.g., 'input', 'keydown')
     * @param listener Listener function
     * @param options Optional event listener options
     */
    addEventListener<K extends keyof HTMLElementEventMap>(type: K, listener: (this: HTMLInputElement, ev: HTMLElementEventMap[K]) => void, options?: boolean | AddEventListenerOptions): void;
    /**
     * Remove an event listener from the input element
     * @param type Event type (e.g., 'input', 'keydown')
     * @param listener Listener function
     * @param options Optional event listener options
     */
    removeEventListener<K extends keyof HTMLElementEventMap>(type: K, listener: (this: HTMLInputElement, ev: HTMLElementEventMap[K]) => void, options?: boolean | EventListenerOptions): void;
}
//# sourceMappingURL=AcEdFloatingInputBox.d.ts.map