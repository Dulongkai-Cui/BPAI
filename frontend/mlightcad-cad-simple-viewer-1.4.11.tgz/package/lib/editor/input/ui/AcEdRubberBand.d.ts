import { AcGePoint2dLike } from '@mlightcad/data-model';
import { AcEdBaseView } from '../../view';
/**
 * Options for the AcEdRubberBand preview.
 */
export interface AcEdRubberBandOptions {
    /**
     * The color used for the rubber-band lines and label. Defaults to green (#0f0).
     */
    color?: string;
    /**
     * The length of the perpendicular lines (perpLineAtBase and perpLineAtCursor)
     * in pixels or world units. Defaults to 50.
     */
    perpendicularLength?: number;
    /**
     * If true, only the baseLine will be shown. Other lines are hidden.
     */
    showBaseLineOnly?: boolean;
}
/**
 * AcEdRubberBand provides a temporary CAD-style rubber-band preview.
 *
 * It can draws a CAD-like reference rectangle:
 * 1. baseLine: solid line from the last point to the cursor.
 * 2. perpLineAtBase: dashed perpendicular line at the base point.
 * 3. perpLineAtCursor: dashed perpendicular line at the cursor.
 * 4. connectorLine: dashed line connecting the ends of the two perpendicular lines.
 * 5. distance label displayed near connectorLine
 *
 * And draw one arc:
 * 1. xAxisLine: horizontal reference line starting at base point
 * 2. angleArc: arc showing angle between baseLine and x-axis (radius = baseLine length)
 * 3. angle label shown at midpoint of the arc
 */
export declare class AcEdRubberBand {
    private view;
    private basePoint?;
    private container;
    private baseLine;
    private perpLineAtBase;
    private perpLineAtCursor;
    private connectorLine;
    private labelEl;
    private angleLabelEl;
    private xAxisLine;
    private angleSvg;
    private anglePath;
    private options;
    /** Returns the parent container element that holds all rubber-band HTML elements. */
    get element(): HTMLDivElement | null;
    constructor(view: AcEdBaseView);
    /**
     * Starts the rubber-band preview.
     * @param basePoint The starting point in world coordinates.
     */
    start(basePoint: AcGePoint2dLike, options?: AcEdRubberBandOptions): void;
    /**
     * Updates the rubber-band lines to a new target point.
     * @param targetPoint The current cursor position in world coordinates.
     */
    update(targetPoint: AcGePoint2dLike): void;
    /** Disposes all HTML elements associated with this rubber-band. */
    dispose(): void;
}
//# sourceMappingURL=AcEdRubberBand.d.ts.map