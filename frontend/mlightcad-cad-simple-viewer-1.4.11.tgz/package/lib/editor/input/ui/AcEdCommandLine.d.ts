import { AcEdPromptKeywordOptions } from '../prompt';
/**
 * AutoCAD-style floating command line with Promise-based execution.
 *
 * Features:
 *  - Floating command bar with left terminal glyph + down toggle and right up toggle
 *  - Command history popup
 *  - Message panel above the bar
 *  - Enter repeats last command if input empty
 *  - Esc cancels current command
 *  - Inline clickable options
 *  - Keyboard navigation
 *  - Promise-based execution for async command handling
 *  - Auto-complete popup for matching commands
 */
export declare class AcEdCommandLine {
    private container;
    private history;
    private historyIndex;
    private lastExecuted;
    private isCmdPopupOpen;
    private isMsgPanelOpen;
    private minWidth;
    private widthRatio;
    private cliContainer;
    private wrapper;
    private bar;
    private leftGroup;
    private closeBtn;
    private downBtn;
    private centerEl;
    private promptEl;
    private textInput;
    private upBtn;
    private cmdPopup;
    private msgPanel;
    private autoCompleteIndex;
    private activeSession?;
    private resizeObserver?;
    constructor(container?: HTMLElement);
    /** Visibility of the command line */
    get visible(): boolean;
    set visible(val: boolean);
    setPrompt(message?: string): void;
    clear(): void;
    clearPrompt(): void;
    clearInput(): void;
    focusInput(): void;
    getKeywords(options: AcEdPromptKeywordOptions): Promise<string>;
    /**
     * Localize a text key using AcApI18n.t().
     *
     * This helper centralizes localization calls for the class and makes
     * it easier to adjust localization behavior in one place if needed.
     *
     * @param key - Localization key (flat key style, e.g. "command.placeholder")
     * @param defaultText - Default English (or fallback) text to use if the key is missing
     * @returns localized string from AcApI18n or the provided defaultText
     */
    private localize;
    /** Refresh all messages when locale changes */
    private refreshLocale;
    /**
     * Execute a command line string.
     * Returns a Promise that resolves when the command is completed.
     * @param cmdLine - Command string
     * @returns Promise<void>
     */
    executeCommand(cmdLine: string): void;
    /** Inject CSS styles */
    private injectCSS;
    /** Create the command line UI elements */
    private createUI;
    /** Bind event listeners */
    private bindEvents;
    /** Handle Enter/Escape keys */
    private handleKeyDown;
    /** Handle input change to show auto-complete */
    private handleInputChange;
    /** Navigate auto-complete list with arrow keys */
    private navigateAutoComplete;
    /** Navigate command history */
    private navigateHistory;
    /** Get current input text */
    private getInputText;
    /** Set input text */
    private setInputText;
    /** Render prompt message and keyword options in command line */
    renderKeywordPrompt(options: AcEdPromptKeywordOptions, onClick: (kw: string) => void): void;
    /** Resolve command name */
    private resolveCommand;
    /** Show or hide popups */
    private updatePopups;
    /** Show command history popup */
    private showCommandHistoryPopup;
    /** Position command history popup */
    private positionCmdPopup;
    /** Show message panel */
    private showMessagePanel;
    /** Position message panel */
    private positionMsgPanel;
    /** Remove "no history" placeholder if present */
    private clearNoHistoryPlaceholder;
    /** Print message to message panel with optional localization key */
    private printMessage;
    /** Print error message with optional localization key */
    private printError;
    /** Print executed command line to history */
    private printHistoryLine;
    /** Handle window resize */
    private resizeHandler;
    private useViewportPositioning;
}
//# sourceMappingURL=AcEdCommandLine.d.ts.map