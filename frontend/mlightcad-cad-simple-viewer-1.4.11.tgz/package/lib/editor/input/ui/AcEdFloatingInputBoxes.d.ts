import { AcEdFloatingInputBox } from './AcEdFloatingInputBox';
import { AcEdFloatingInputCancelCallback, AcEdFloatingInputChangeCallback, AcEdFloatingInputCommitCallback, AcEdFloatingInputRawData, AcEdFloatingInputValidationCallback } from './AcEdFloatingInputTypes';
/**
 * Construction options for {@link AcEdFloatingInputBoxes}.
 */
export interface AcEdFloatingInputBoxesOptions<T> {
    /**
     * The parent element to constrain the floating input within.
     */
    parent: HTMLElement;
    /**
     * If true, display both X and Y inputs.
     * If false, display only X input (useful for distance, angle, etc.).
     *
     * Default: `true`
     */
    twoInputs?: boolean;
    /**
     * Custom validation function.
     */
    validate: AcEdFloatingInputValidationCallback<T>;
    /**
     * Callback invoked when user confirms valid input by pressing Enter.
     */
    onCommit?: AcEdFloatingInputCommitCallback<T>;
    /**
     * Callback invoked on each input event after validation completes.
     */
    onChange?: AcEdFloatingInputChangeCallback<T>;
    /**
     * Callback invoked on cancellation (Escape or hide()).
     */
    onCancel?: AcEdFloatingInputCancelCallback;
}
/**
 * Container holding one or two floating input boxes.
 *
 * Always contains:
 *      - X input box
 *
 * Contains Y input box only if `twoInputs` is true.
 */
export declare class AcEdFloatingInputBoxes<T> {
    /** Root DOM node that contains X and optional Y input boxes */
    readonly parent: HTMLElement;
    /** Whether this input uses X+Y fields or X-only. @private */
    readonly twoInputs: boolean;
    /** Always present */
    readonly xInput: AcEdFloatingInputBox;
    /** Only present when twoInputs = true */
    readonly yInput?: AcEdFloatingInputBox;
    /**
     * Cached bound handler for keyboard events—ensures removal works.
     */
    private boundOnKeyDown;
    /**
     * Cached bound handler for input events—ensures removal works.
     */
    private boundOnInput;
    private onCommit?;
    private onChange?;
    private onCancel?;
    private validateFn;
    /**
     * Constructs one instance of this class
     * @param parent - The container element of X and Y inputs
     * @param twoInputs - The flag whether to show Y input
     */
    constructor(options: AcEdFloatingInputBoxesOptions<T>);
    /** Returns true if user typed in ANY input box */
    get userTyped(): boolean;
    /** Return one flag to indicate whether one of inputs is focused. */
    get focused(): boolean | undefined;
    /** Focus on X input */
    focus(): void;
    /** Sets text value of X and Y inputs if user doesn't type value */
    setValue(value: AcEdFloatingInputRawData): void;
    /**
     * Disposes the floating input widget permanently.
     *
     * - Removes all event listeners (keyboard, input, mouse move).
     * - Removes the widget's DOM container from the parent.
     * - Marks the widget as disposed; after this, it cannot be shown again.
     *
     * Safe to call multiple times; subsequent calls have no effect.
     */
    dispose(): void;
    /**
     * Handles input events from X or Y fields.
     * Triggers validation and notifies listeners through `onChange`.
     */
    private handleInput;
    /**
     * Handles keyboard events (Enter for commit, Escape for cancel).
     */
    private handleKeyDown;
    /**
     * Validates the input values using either:
     * - the user-provided custom validation function, OR
     * - the built-in numeric parser.
     */
    private validate;
}
//# sourceMappingURL=AcEdFloatingInputBoxes.d.ts.map