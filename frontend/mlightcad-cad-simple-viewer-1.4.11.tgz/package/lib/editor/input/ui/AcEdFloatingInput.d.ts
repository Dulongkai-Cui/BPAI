import { AcGePoint2d } from '@mlightcad/data-model';
import { AcEdBaseView } from '../../view';
import { AcEdFloatingInputOptions } from './AcEdFloatingInputTypes';
import { AcEdFloatingMessage } from './AcEdFloatingMessage';
/**
 * A UI component providing a small floating input box used inside CAD editing
 * workflows. It supports both single-input (distance, angle, etc.) and
 * double-input (coordinate entry) modes.
 *
 * The component is responsible for:
 *
 * - Creating, styling, and destroying its HTML structure
 * - Handling keyboard events (Enter, Escape)
 * - Managing live validation (via built-in or custom callback)
 * - Emitting commit/change/cancel events
 * - Ensuring no memory leaks via `dispose()`
 *
 * This abstraction allows higher-level objects such as AcEdInputManager to
 * remain clean and free from DOM-handling logic.
 */
export declare class AcEdFloatingInput<T> extends AcEdFloatingMessage {
    /** Stores last confirmed WCS point */
    lastPoint: AcGePoint2d | null;
    /** Inject styles only once */
    private static inputStylesInjected;
    /** Input box container (single or double input) */
    private inputs?;
    /** Provides a temporary CAD-style rubber-band preview. */
    private rubberBand?;
    /** OSNAP marker manager to display and hide OSNAP marker */
    private osnapMarkerManager?;
    /** Stores last confirmed osnap point */
    private lastOsnapPoint?;
    /** Callbacks */
    private onCommit?;
    private onChange?;
    private onCancel?;
    /** Validation and dynamic value providers */
    private validateFn;
    private getDynamicValue;
    private drawPreview?;
    /** Cached click handler */
    private boundOnClick;
    /**
     * Constructs a new floating input widget with the given options.
     *
     * @param view - The view associated with the floating input
     * @param options Configuration object controlling behavior, callbacks,
     *                validation, and display mode.
     */
    constructor(view: AcEdBaseView, options: AcEdFloatingInputOptions<T>);
    private injectInputCSS;
    dispose(): void;
    /**
     * Mouse move handler.
     * Updates dynamic input values, rubber-band preview, OSNAP marker,
     * and optional preview drawing.
     */
    protected handleMouseMove(e: MouseEvent): void;
    private handleClick;
    /**
     * Gets the current cursor position in WCS, considering OSNAP.
     */
    private getPosition;
    private osnapMode2MarkerType;
    private getOsnapPoint;
    private getOsnapPoints;
    private getOsnapPointsInAvailableModes;
    private getOsnapPointsByMode;
}
//# sourceMappingURL=AcEdFloatingInput.d.ts.map