import { AcGeBox2d, AcGePoint3dLike } from '@mlightcad/data-model';
import { AcEdBaseView } from '../../view';
import { AcEdPromptAngleOptions, AcEdPromptBoxOptions, AcEdPromptDistanceOptions, AcEdPromptEntityOptions, AcEdPromptIntegerOptions, AcEdPromptKeywordOptions, AcEdPromptPointOptions, AcEdPromptSelectionOptions, AcEdPromptStringOptions } from '../prompt';
/**
 * A fully type-safe TypeScript class providing CAD-style interactive user input
 * using floating HTML input boxes and mouse events. Supports collecting points,
 * distances, angles, numbers, strings, and selecting a 2-point rectangular box
 * using an HTML overlay rectangle (suitable when the main canvas is a THREE.js
 * WebGL canvas).
 */
export declare class AcEdInputManager {
    /** Inject styles only once */
    private static stylesInjected;
    /** The view associated with this input operation */
    protected view: AcEdBaseView;
    /** Stores last confirmed point from getPoint() or getBox() */
    private lastPoint;
    /** Command line UI component */
    private _commandLine;
    /** Buffered command-line style inputs (each item is one Enter-confirmed value). */
    private _scriptInputs;
    /**
     * The flag to indicate whether it is currently in an “input acquisition” mode (e.g., point
     * selection, distance/angle prompt, string prompt, etc.),
     */
    private active;
    /**
     * Construct the manager and attach mousemove listener used for floating input
     * positioning and live preview updates.
     *
     * @param view - The view associated with the input manager
     */
    constructor(view: AcEdBaseView);
    /**
     * The flag to indicate whether it is currently in an “input acquisition” mode (e.g., point
     * selection, distance/angle prompt, string prompt, etc.),
     */
    get isActive(): boolean;
    /**
     * Queue scripted inputs for subsequent getXXX calls.
     * One array item equals one Enter-confirmed value.
     */
    enqueueScriptInputs(inputs: string[]): void;
    /** Clears any pending scripted inputs. */
    clearScriptInputs(): void;
    /**
     * Injects minimal CSS required for the floating input and preview rectangle.
     * Useful when you do not have a separate CSS file.
     */
    private injectCSS;
    /**
     * Format a number for display in input box.
     * Default: 3 decimal places for points/distance, 2 decimal places for angles.
     * @param value The numeric value
     * @param type Optional type: 'point' | 'distance' | 'angle'
     */
    private formatNumber;
    /**
     * Public point input API.
     */
    getPoint(options: AcEdPromptPointOptions): Promise<AcGePoint3dLike>;
    /**
     * Prompt the user to type a numeric value. If integerOnly is true, integers
     * are enforced. The input is validated and the box will be marked invalid if
     * the typed value does not conform, allowing the user to retype.
     */
    private getNumberTyped;
    /** Request a distance (number) from the user. */
    getDistance(options: AcEdPromptDistanceOptions): Promise<number>;
    /** Request an angle in degrees from the user. */
    getAngle(options: AcEdPromptAngleOptions): Promise<number>;
    /** Request a double/float from the user. */
    getDouble(options: AcEdPromptDistanceOptions): Promise<number>;
    /** Request an integer from the user. */
    getInteger(options: AcEdPromptIntegerOptions): Promise<number>;
    /**
     * Prompt the user to type an arbitrary string. Resolved when Enter is pressed.
     */
    getString(options: AcEdPromptStringOptions): Promise<string>;
    /**
     * Prompt the user to type a keyword. Resolved when Enter is pressed.
     */
    getKeywords(options: AcEdPromptKeywordOptions): Promise<string>;
    /**
     * Prompts the user to select one or more entities by mouse interaction.
     *
     * This method supports two selection modes:
     *
     * - **Click selection**: Clicking on an entity selects the entity under the cursor.
     * - **Box selection**: Dragging the mouse to let the user specify a rectangular window,
     *   and all entities intersecting that box are selected.
     *
     * The selection operation behaves similarly to AutoCAD's
     * `Editor.GetSelection()` API:
     *
     * - Press **Enter** to accept the current selection set.
     * - Press **Escape** to cancel the operation.
     * - If {@link AcEdPromptSelectionOptions.singleOnly} is `true`, the selection
     *   completes immediately after the first entity is selected.
     *
     * This method does not use floating input boxes. Instead, it relies entirely on
     * mouse gestures and keyboard input. A floating prompt message and command line
     * prompt are displayed during the operation.
     *
     * @param options - Selection prompt options that control user messaging and
     *                  whether only a single entity may be selected.
     * @returns A promise that resolves to an array of selected entity IDs.
     *          The array is empty if no entities are selected and the user presses Enter.
     *          The promise is rejected if the operation is cancelled.
     */
    getSelection(options: AcEdPromptSelectionOptions): Promise<string[]>;
    /**
     * Prompts the user to select a single entity.
     * Similar to Editor.GetEntity() in AutoCAD.
     */
    getEntity(options: AcEdPromptEntityOptions): Promise<string | null>;
    /**
     * Prompt the user to specify a rectangular box by selecting two corners.
     * Each corner may be specified by clicking on the canvas or typing "x,y".
     * A live HTML overlay rectangle previews the box as the user moves the mouse.
     */
    getBox(options: AcEdPromptBoxOptions): Promise<AcGeBox2d>;
    /**
     * Shared point input logic used by getPoint() and getBox(). Accepts "x,y"
     * typed input OR mouse click.
     */
    private getPointInternal;
    /**
     * Attempts to consume one scripted input and parse it as a point.
     * Supported forms: "x,y", "x,y,z", or "x y".
     */
    private tryGetScriptedPoint;
    /**
     * Attempts to consume one scripted input and parse it with the supplied handler.
     */
    private tryGetScriptedValue;
    private tryGetScriptedNumber;
    private dequeueScriptInput;
    private splitScriptedPoint;
    /**
     * Creates a promise for floating input that will be resolved or rejected by user input.
     *
     * This method centralizes the lifecycle of an interactive input operation,
     * including handling the Escape key to cancel, resolving with user-provided
     * values, and guaranteeing cleanup of UI elements and event handlers.
     */
    private makeFloatingInputPromise;
}
//# sourceMappingURL=AcEdInputManager.d.ts.map