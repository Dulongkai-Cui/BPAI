/**
 * A utility class that waits until a specified condition is met
 * or a timeout occurs, and then executes a single action.
 *
 * @example
 * ```ts
 * const waiter = new AcEdConditionWaiter(
 *   () => isDataReady(),     // condition
 *   () => log.info('Ready or timed out'), // action
 *   1000,                    // check every 1s
 *   10000                    // timeout after 10s
 * );
 *
 * waiter.start();
 * ```
 */
export declare class AcEdConditionWaiter {
    private readonly condition;
    private readonly action;
    private readonly checkInterval;
    private readonly timeout;
    private timerId;
    private timeoutId;
    /**
     * Creates a new AcEdConditionWaiter.
     *
     * @param condition - The condition function to check periodically.
     * @param action - The action to execute once when the condition is met or timeout occurs.
     * @param checkInterval - How often (ms) to check the condition. Default: 1000 ms.
     * @param timeout - Maximum time (ms) to wait before executing the action. Default: 0 (no timeout).
     */
    constructor(condition: () => boolean, action: () => void, checkInterval?: number, timeout?: number);
    /**
     * Starts checking the condition at the defined interval.
     * Executes the action once when the condition becomes true or when timeout is reached.
     */
    start(): void;
    /**
     * Stops all checking without triggering the action.
     */
    stop(): void;
    /**
     * Internal helper to execute the action and stop all timers.
     */
    private executeAndStop;
    /**
     * Checks whether the waiter is currently active.
     */
    isRunning(): boolean;
}
//# sourceMappingURL=AcEdConditionWaiter.d.ts.map